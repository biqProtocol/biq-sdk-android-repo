package biq.sdk.android.managers

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import biq.sdk.android.BiqController
import biq.sdk.android.helpers.extensions.logDebugMessage
import biq.sdk.android.helpers.extensions.logErrorMessage
import biq.sdk.android.models.BiqNetworkState
import biq.sdk.android.providers.ConnectionStateProvider
import biq.sdk.android.providers.ContextProvider

object NetworkConnectivityManager {

    private var isInitialized = false
    private var isRegistered = false

    private lateinit var connectivityManager: ConnectivityManager

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            "[BIQ][NCM] Network Available.".logDebugMessage()
            if(ConnectionStateProvider.networkState == BiqNetworkState.NETWORK_LOST) {
                BiqController.getInstance().startPresence(false)
            }
            ConnectionStateProvider.updateNetworkState(BiqNetworkState.NETWORK_AVAILABLE)
        }

        override fun onLost(network: Network) {
            "[BIQ][NCM] Network Lost.".logDebugMessage()
            BiqController.getInstance().stopPresence(true)
            ConnectionStateProvider.updateNetworkState(BiqNetworkState.NETWORK_LOST)
        }
    }

    fun init() {
        if (isInitialized) return

        connectivityManager = ContextProvider.get().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        isInitialized = true
    }

    fun isConnected(): Boolean {
        val activeNetwork = connectivityManager.activeNetwork ?: return false
        val networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
        return networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun register() {
        if (!isInitialized || isRegistered) return

        ConnectionStateProvider.updateNetworkState(BiqNetworkState.UNKNOWN)

        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        connectivityManager.registerNetworkCallback(request, networkCallback)
        isRegistered = true
    }

    fun unregister() {
        if (!isInitialized || !isRegistered) return

        try {
            connectivityManager.unregisterNetworkCallback(networkCallback)
        } catch (e: Exception) {
            "[BIQ][NCM] Error during unregister: ${e.message}".logErrorMessage()
        } finally {
            ConnectionStateProvider.updateNetworkState(BiqNetworkState.UNKNOWN)
            isRegistered = false
        }
    }
}
