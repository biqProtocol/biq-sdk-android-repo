package biq.sdk.android.providers

import biq.sdk.android.BiqController
import biq.sdk.android.models.BiqNetworkState
import biq.sdk.android.models.BiqPresenceState
import biq.sdk.android.models.BiqScanningState

internal object ConnectionStateProvider {
    var state: BiqPresenceState = BiqPresenceState.UNKNOWN
        private set

    var scanningState: BiqScanningState = BiqScanningState.UNKNOWN
        private set

    var networkState: BiqNetworkState = BiqNetworkState.UNKNOWN
        private set

    fun updateState(state: BiqPresenceState) {
        this.state = state

        when (state) {
            BiqPresenceState.SCANNING_IN_PROGRESS -> updateScanningState(BiqScanningState.SCANNING_IN_PROGRESS)
            BiqPresenceState.SCANNING_NOT_STARTED -> updateScanningState(BiqScanningState.SCANNING_NOT_STARTED)
            else -> Unit
        }

        BiqController.getInstance().notifyStateChange(state)
    }

    private fun updateScanningState(state: BiqScanningState) {
        this.scanningState = state

        BiqController.getInstance().notifyScanningChange(state)
    }

    fun updateNetworkState(state: BiqNetworkState) {
        this.networkState = state

        if (state == BiqNetworkState.NETWORK_LOST) {
            updateState(BiqPresenceState.NETWORK_ERROR)
        }
    }
}
