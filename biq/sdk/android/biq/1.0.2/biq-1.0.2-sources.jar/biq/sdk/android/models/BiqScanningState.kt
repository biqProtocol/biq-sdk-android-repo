package biq.sdk.android.models

enum class BiqScanningState(id: Int) {
    UNKNOWN(0),
    SCANNING_NOT_STARTED(1),
    SCANNING_IN_PROGRESS(2)
}