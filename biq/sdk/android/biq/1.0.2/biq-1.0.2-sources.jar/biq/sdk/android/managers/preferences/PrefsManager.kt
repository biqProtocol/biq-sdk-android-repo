package biq.sdk.android.managers.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import biq.sdk.android.providers.ContextProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.time.LocalDateTime

// Create extension to get DataStore instance
private val Context.dataStore by preferencesDataStore(name = "biq_sdk_prefs")

internal object PrefsManager {

    private val context: Context get() = ContextProvider.get()

    private const val SCANNING_NOTIFICATION_TITLE_KEY = "scanningNotificationTitle"
    private const val SCANNING_NOTIFICATION_MESSAGE_KEY = "scanningNotificationMessage"
    private const val PROXIMITY_NOTIFICATION_TITLE_KEY = "proximityNotificationTitle"
    private const val PROXIMITY_NOTIFICATION_MESSAGE_KEY = "proximityNotificationMessage"
    private const val NOTIFICATION_ICON_KEY = "notificationIcon"
    private const val BOOT_ACTIVATION_KEY = "isBootStartAvailable"
    private const val DEBUG_MODE_KEY = "isDebugAvailable"

    private suspend fun writeString(key: String, value: String) = withContext(Dispatchers.IO) {
        context.dataStore.edit { prefs ->
            prefs[stringPreferencesKey(key)] = value
        }
    }

    private suspend fun readString(key: String): String? = withContext(Dispatchers.IO) {
        val prefKey = stringPreferencesKey(key)
        val prefs = context.dataStore.data.first()
        prefs[prefKey]
    }

    private suspend fun writeBoolean(key: String, value: Boolean) = withContext(Dispatchers.IO) {
        context.dataStore.edit { prefs ->
            prefs[booleanPreferencesKey(key)] = value
        }
    }

    private suspend fun readBoolean(key: String): Boolean? = withContext(Dispatchers.IO) {
        val prefKey = booleanPreferencesKey(key)
        val prefs = context.dataStore.data.first()
        prefs[prefKey]
    }

    private suspend fun writeInt(key: String, value: Int) = withContext(Dispatchers.IO) {
        context.dataStore.edit { prefs ->
            prefs[intPreferencesKey(key)] = value
        }
    }

    private suspend fun readInt(key: String): Int? = withContext(Dispatchers.IO) {
        val prefKey = intPreferencesKey(key)
        val prefs = context.dataStore.data.first()
        prefs[prefKey]
    }

    private suspend fun remove(key: String) = withContext(Dispatchers.IO) {
        context.dataStore.edit { prefs ->
            prefs.remove(stringPreferencesKey(key))
        }
    }

    suspend fun saveBeaconDate(beaconId: String) =
        writeString(beaconId, LocalDateTime.now().toString())

    suspend fun getBeaconDate(beaconId: String) =
        readString(beaconId)?.let { LocalDateTime.parse(it) }


    suspend fun saveScanningNotificationTitle(title: String) =
        writeString(SCANNING_NOTIFICATION_TITLE_KEY, title)

    suspend fun getScanningNotificationTitle() =
        readString(SCANNING_NOTIFICATION_TITLE_KEY)


    suspend fun saveScanningNotificationMessage(message: String) =
        writeString(SCANNING_NOTIFICATION_MESSAGE_KEY, message)

    suspend fun getScanningNotificationMessage() =
        readString(SCANNING_NOTIFICATION_MESSAGE_KEY)


    suspend fun saveProximityNotificationTitle(title: String) =
        writeString(PROXIMITY_NOTIFICATION_TITLE_KEY, title)

    suspend fun getProximityNotificationTitle() =
        readString(PROXIMITY_NOTIFICATION_TITLE_KEY)


    suspend fun saveProximityNotificationMessage(message: String) =
        writeString(PROXIMITY_NOTIFICATION_MESSAGE_KEY, message)

    suspend fun getProximityNotificationMessage() =
        readString(PROXIMITY_NOTIFICATION_MESSAGE_KEY)


    suspend fun saveNotificationIcon(icon: Int) = writeInt(NOTIFICATION_ICON_KEY, icon)

    suspend fun getNotificationIcon() = readInt(NOTIFICATION_ICON_KEY)


    suspend fun saveStartAfterBootPreference(isStartAfterBoot: Boolean) =
        writeBoolean(BOOT_ACTIVATION_KEY, isStartAfterBoot)

    suspend fun getStartAfterBootPreference() =
        readBoolean(BOOT_ACTIVATION_KEY) ?: false


    suspend fun saveDebugModePreference(iseDebugAvailable: Boolean) =
        writeBoolean(DEBUG_MODE_KEY, iseDebugAvailable)

    suspend fun getDebugModePreference() =
        readBoolean(DEBUG_MODE_KEY) ?: false
}