package biq.sdk.android.networking.services

import biq.sdk.android.networking.models.PresenceProofRequestDto
import biq.sdk.android.networking.models.PresenceProofResponseDto
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

internal interface PresenceProofService {
    @GET("api/protocol/v0/nonce")
    suspend fun getNonce(): String

    @POST("api/protocol/v0/validate")
    suspend fun validateSignature(
        @Body signaturesList: List<PresenceProofRequestDto>
    ): PresenceProofResponseDto
}