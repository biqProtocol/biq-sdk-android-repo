package biq.sdk.android.data.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import biq.sdk.android.networking.models.EventAreaDto

@Entity(tableName = "eventAreaEntity")
data class EventAreaEntity(
    @PrimaryKey
    val id: String,
    @ColumnInfo(name = COLUMN_LOCATION_ID)
    val locationId: String,
    val name: String,
    val description: String,
    val image: String,
    val beacons: List<String>?
) {
    companion object {
        const val COLUMN_LOCATION_ID = "locationId"
    }
}

fun EventAreaEntity.toDto() = EventAreaDto(
    id = id,
    name = name,
    description = description,
    image = image,
    beacons = beacons
)