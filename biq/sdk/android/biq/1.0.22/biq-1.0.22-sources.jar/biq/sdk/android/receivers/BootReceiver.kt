package biq.sdk.android.receivers

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import biq.sdk.android.BiqController
import biq.sdk.android.helpers.extensions.logDebugMessage
import biq.sdk.android.managers.NotificationsManager
import biq.sdk.android.managers.preferences.DebugPrefsManager
import biq.sdk.android.managers.preferences.PrefsManager
import biq.sdk.android.providers.CoroutineScopeProvider
import biq.sdk.android.providers.UserSessionProvider
import kotlinx.coroutines.launch

// TODO include Manifest declaration into read.me --> should be done by the host app
class BootReceiver : BroadcastReceiver() {
    @SuppressLint("ObsoleteSdkInt")
    override fun onReceive(context: Context, intent: Intent?) {

        "[BIQ][BR] BootReceiver.onReceive() with action: ${intent?.action}".logDebugMessage()

        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            "[BIQ][BR] ACTION_BOOT_COMPLETED".logDebugMessage()

            BiqController.Builder(context).build()

            CoroutineScopeProvider.get().launch {
                //TODO if return, inform integrator that boot load was unsuccessful
                if(!PrefsManager.getStartAfterBootPreference()) {
                    DebugPrefsManager.saveBootLoadedStates(false)
                    return@launch
                }

                val refreshToken = UserSessionProvider.getRefresh() ?: run {
                    DebugPrefsManager.saveBootLoadedStates(false)
                    return@launch
                }
                val apiKey = UserSessionProvider.getApi() ?: run {
                    DebugPrefsManager.saveBootLoadedStates(false)
                    return@launch
                }

                val isDebug = PrefsManager.getDebugModePreference()

                BiqController.getInstance().apply {
                    init(
                        refreshToken = refreshToken,
                        apiKey = apiKey
                    )
                    setDebugMode(isDebug)
                    startPresence ()
                }

                NotificationsManager.loadNotificationData()

                DebugPrefsManager.saveBootLoadedStates(true)
            }
        }
    }
}