package biq.sdk.android.managers

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.core.content.FileProvider
import biq.sdk.android.providers.ContextProvider
import biq.sdk.android.providers.CoroutineScopeProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

internal enum class LogLevel(val label: String) {
    ERROR("ERROR"),
    WARNING("WARN"),
    INFO("INFO"),
    DEBUG("DEBUG")
}

internal object LogsManager {
    private const val TAG = "LogsManager"
    private const val LOGS_FOLDER = "biq_logs"
    private const val LOG_RETENTION_DAYS = 7L

    private val fileMutex = Mutex()
    private val dateFormatter = DateTimeFormatter.ofPattern("dd_MM_yyyy")
    private val timestampFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")

    fun recordLog(level: LogLevel, tag: String?, message: String) {
        CoroutineScopeProvider.get().launch {
            appendLog(level, tag, message)
        }
    }

    private suspend fun appendLog(level: LogLevel, tag: String?, message: String) {
        val context = ContextProvider.get()
        val logLine = buildString {
            append(LocalDateTime.now().format(timestampFormatter))
            append(" [").append(level.label).append("]")
            if (!tag.isNullOrBlank()) {
                append(" [").append(tag).append("]")
            }
            append(" ").append(message)
        }

        withContext(Dispatchers.IO) {
            fileMutex.withLock {
                runCatching {
                    val logFile = getDailyLogFile(context)
                    logFile.appendText(logLine + "\n")
                }.onFailure { error ->
                    Log.e(TAG, "Failed to persist log entry", error)
                }
            }
        }
    }

    fun shareLogs(): Boolean {
        val context = ContextProvider.get()
        val files = logsDirectory(context).listFiles()?.filter { it.isFile }?.toList().orEmpty()
        if (files.isEmpty()) {
            Log.w(TAG, "No logs available to share.")
            return false
        }

        CoroutineScopeProvider.get().launch {
            val zipFile = createLogsZip(context) ?: return@launch
            val uri = buildUri(context, zipFile) ?: return@launch
            withContext(Dispatchers.Main) {
                shareUri(context, uri)
            }
        }

        return true
    }

    private fun logsDirectory(context: Context): File {
        return File(context.filesDir, LOGS_FOLDER)
    }

    private fun getDailyLogFile(context: Context): File {
        val directory = logsDirectory(context)
        if (!directory.exists()) {
            directory.mkdirs()
        }
        purgeOldLogs(directory)

        val filename = "Biq_Android_${LocalDate.now().format(dateFormatter)}.txt"
        return File(directory, filename)
    }

    private fun purgeOldLogs(directory: File) {
        val cutoffDate = LocalDate.now().minusDays(LOG_RETENTION_DAYS)
        directory.listFiles()?.forEach { file ->
            if (!file.isFile) return@forEach
            val fileDate = runCatching {
                val datePart = file.name
                    .removePrefix("Biq_Android_")
                    .removeSuffix(".txt")
                LocalDate.parse(datePart, dateFormatter)
            }.getOrNull() ?: return@forEach

            if (fileDate.isBefore(cutoffDate)) {
                file.delete()
            }
        }
    }

    private suspend fun createLogsZip(context: Context): File? = withContext(Dispatchers.IO) {
        val logFiles = logsDirectory(context).listFiles()?.filter { it.isFile }.orEmpty()
        if (logFiles.isEmpty()) {
            return@withContext null
        }

        val cacheDir = context.cacheDir
        cleanupOldZips(cacheDir)

        val zipFile = File(cacheDir, "biq_logs_${System.currentTimeMillis()}.zip")
        runCatching {
            ZipOutputStream(FileOutputStream(zipFile)).use { zipStream ->
                logFiles.forEach { logFile ->
                    FileInputStream(logFile).use { input ->
                        val entry = ZipEntry(logFile.name)
                        zipStream.putNextEntry(entry)
                        input.copyTo(zipStream)
                        zipStream.closeEntry()
                    }
                }
            }
            zipFile
        }.onFailure { error ->
            Log.e(TAG, "Failed to zip log files", error)
            zipFile.delete()
        }.getOrNull()
    }

    private fun cleanupOldZips(cacheDir: File) {
        cacheDir.listFiles { file ->
            file.isFile && file.name.startsWith("biq_logs_") && file.extension == "zip"
        }?.forEach { it.delete() }
    }

    private fun buildUri(context: Context, file: File): Uri? {
        return runCatching {
            val authority = "${context.packageName}.biq.sdk.android.fileprovider"
            FileProvider.getUriForFile(context, authority, file)
        }.onFailure { error ->
            Log.e(TAG, "Failed to build URI for log archive", error)
        }.getOrNull()
    }

    private fun shareUri(context: Context, uri: Uri) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            clipData = ClipData.newUri(context.contentResolver, "BIQ logs", uri)
        }

        runCatching {
            val chooser = Intent.createChooser(intent, "Share BIQ logs").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        }.onFailure { error ->
            Log.e(TAG, "Failed to share log archive", error)
        }
    }
}
