package biq.sdk.android.helpers.utils

object Base58 {
    private const val ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    private val BASE58 = ALPHABET.toCharArray()
    private val INDEXES = IntArray(128) { -1 }

    init {
        for (i in BASE58.indices) {
            INDEXES[BASE58[i].code] = i
        }
    }

    fun encode(input: ByteArray): String {
        if (input.isEmpty()) return ""

        // Count leading zeros.
        var zeros = 0
        while (zeros < input.size && input[zeros] == 0.toByte()) {
            ++zeros
        }

        // Convert base-256 digits to base-58 digits.
        val inputCopy = input.copyOf()
        val encoded = StringBuilder()
        var startAt = zeros
        while (startAt < inputCopy.size) {
            val mod = divmod58(inputCopy, startAt)
            if (inputCopy[startAt] == 0.toByte()) {
                ++startAt
            }
            encoded.append(BASE58[mod])
        }

        // Add leading zeros.
        repeat(zeros) { encoded.append('1') }

        return encoded.reverse().toString()
    }

    fun decode(input: String): ByteArray {
        if (input.isEmpty()) return ByteArray(0)

        // Convert the base58 string to a base256 byte array.
        val input58 = ByteArray(input.length)
        for (i in input.indices) {
            val c = input[i]
            val digit = if (c.code < 128) INDEXES[c.code] else -1
            require(digit >= 0) { "Invalid Base58 character: '$c'" }
            input58[i] = digit.toByte()
        }

        // Count leading zeros.
        var zeros = 0
        while (zeros < input58.size && input58[zeros].toInt() == 0) {
            ++zeros
        }

        // Convert base-58 digits to base-256 bytes.
        val decoded = ByteArray(input.length)
        var outputStart = decoded.size
        var inputStart = zeros
        while (inputStart < input58.size) {
            val mod = divmod256(input58, inputStart)
            if (input58[inputStart] == 0.toByte()) {
                ++inputStart
            }
            decoded[--outputStart] = mod
        }

        // Ignore extra leading zeroes
        return decoded.copyOfRange(outputStart - zeros, decoded.size)
    }

    private fun divmod58(number: ByteArray, startAt: Int): Int {
        var remainder = 0
        for (i in startAt until number.size) {
            val digit256 = number[i].toInt() and 0xFF
            val temp = remainder * 256 + digit256
            number[i] = (temp / 58).toByte()
            remainder = temp % 58
        }
        return remainder
    }

    private fun divmod256(number: ByteArray, startAt: Int): Byte {
        var remainder = 0
        for (i in startAt until number.size) {
            val digit58 = number[i].toInt() and 0xFF
            val temp = remainder * 58 + digit58
            number[i] = (temp / 256).toByte()
            remainder = temp % 256
        }
        return remainder.toByte()
    }
}
