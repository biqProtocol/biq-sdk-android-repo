package biq.sdk.android.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import biq.sdk.android.BiqController
import biq.sdk.android.helpers.extensions.logDebugMessage
import biq.sdk.android.helpers.extensions.logErrorMessage
import biq.sdk.android.managers.event.EventCleanupScheduler
import biq.sdk.android.providers.ContextProvider
import biq.sdk.android.providers.DatabaseProvider
import java.util.concurrent.TimeUnit

internal class EventCleanupWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val eventId = inputData.getString(KEY_EVENT_ID)
            ?: run {
                "[BIQ][ECW] Missing eventId input".logErrorMessage()
                return Result.failure()
            }

        return runCatching {
            ContextProvider.init(applicationContext)
            DatabaseProvider.init()
            val repository = DatabaseProvider.getEventRepository()

            repository.deleteById(eventId)

            val retentionThreshold = System.currentTimeMillis() -
                    TimeUnit.MINUTES.toMillis(EventCleanupScheduler.CLEANUP_DELAY_MINUTES)
            repository.deleteOlderThan(retentionThreshold)

            repository.getAll()
        }.fold(
            onSuccess = { remainingEvents ->
                "[BIQ][ECW] Event with id $eventId deleted successfully.".logDebugMessage()
                runCatching { BiqController.getInstance() }
                    .getOrNull()
                    ?.notifyValidationRecordsChange(remainingEvents)
                    ?: "[BIQ][ECW] BiqController not initialized; skipping event with validation records update.".logDebugMessage()
                Result.success()
            },
            onFailure = { error ->
                "[BIQ][ECW] Failed to clear events for $eventId: ${error.message}".logErrorMessage()
                Result.retry()
            }
        )
    }

    companion object {
        const val KEY_EVENT_ID = "event_id"
    }
}
