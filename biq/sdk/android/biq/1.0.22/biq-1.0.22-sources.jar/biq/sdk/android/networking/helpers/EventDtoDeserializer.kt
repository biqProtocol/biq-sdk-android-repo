package biq.sdk.android.networking.helpers

import biq.sdk.android.networking.models.EventDto
import com.google.gson.*

class EventDtoDeserializer : JsonDeserializer<EventDto> {
    override fun deserialize(
        json: JsonElement,
        typeOfT: java.lang.reflect.Type,
        context: JsonDeserializationContext
    ): EventDto {
        val dto = Gson().fromJson(json, EventDto::class.java)
        return dto.copy(rawData = json.toString())
    }
}
