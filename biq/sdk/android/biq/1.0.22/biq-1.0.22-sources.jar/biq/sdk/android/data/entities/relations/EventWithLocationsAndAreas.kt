package biq.sdk.android.data.entities.relations

import biq.sdk.android.data.entities.EventEntity
import biq.sdk.android.networking.models.EventDto

data class EventWithLocationsAndAreas(
    val event: EventEntity,
    val locations: List<LocationWithAreas>
)

fun EventWithLocationsAndAreas.toDto() = EventDto(
    id = event.id,
    type = event.type,
    name = event.name,
    description = event.description,
    image = event.image,
    organizer = event.organizer,
    url = event.url,
    startTime = event.startTime,
    endTime = event.endTime,
    isPublic = event.isPublic,
    isGated = event.isGated,
    tags = event.tags,
    owners = event.owners,
    locations = locations.map { it.toDto() },
    rawData = event.rawData
)
