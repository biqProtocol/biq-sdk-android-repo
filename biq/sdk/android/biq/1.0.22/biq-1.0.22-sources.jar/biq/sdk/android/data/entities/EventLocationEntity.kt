package biq.sdk.android.data.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "eventLocationEntity")
data class EventLocationEntity(
    @PrimaryKey
    @ColumnInfo(name = COLUMN_ID)
    val id: String,
    @ColumnInfo(name = COLUMN_EVENT_ID)
    val eventId: String,
    val name: String,
    val address: String,
    val mapLink: String,
    val beacons: List<String>?,
    val allowUserBeacons: Boolean?,
    val lat: Double?,
    val lng: Double?,
    val radius: Double?
) {
    companion object {
        const val COLUMN_ID = "id"
        const val COLUMN_EVENT_ID = "eventId"
    }
}