package biq.sdk.android.providers

import android.content.Context
import android.content.pm.ApplicationInfo
import biq.sdk.android.BuildConfig
import biq.sdk.android.managers.preferences.PrefsManager
import kotlinx.coroutines.launch

internal object DebugModeProvider {
    private var isDebugModeEnabled: Boolean = false

    fun init(isDebugModeEnabled: Boolean) {
        this.isDebugModeEnabled = isDebugModeEnabled

        CoroutineScopeProvider.get().launch {
            PrefsManager.saveDebugModePreference(isDebugModeEnabled)
        }
    }

    val isDebugOn: Boolean
        get() = this.isDebugModeEnabled && ContextProvider.get().isAppDebuggable()

    val isDebugOff: Boolean
        get() = !isDebugOn
}

private fun Context.isAppDebuggable(): Boolean {
    return (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
}