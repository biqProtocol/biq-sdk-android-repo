package biq.sdk.android.networking.models

internal data class RefreshAuthRequestDto(
    val refreshToken: String
)

internal data class RefreshAuthResponseDto(
    val idToken: String
)