package biq.sdk.android.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import biq.sdk.android.data.entities.EventLocationEntity

@Dao
internal interface EventLocationDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(locations: List<EventLocationEntity>)

    @Query("DELETE FROM eventLocationEntity WHERE eventId = :eventId")
    suspend fun deleteByEventId(eventId: String)

    @Query("DELETE FROM eventLocationEntity WHERE eventId IN (:eventIds)")
    suspend fun deleteByEventIds(eventIds: List<String>)

    @Query("DELETE FROM eventLocationEntity")
    suspend fun deleteAll()

}
