package biq.sdk.android.data.repositories.event

import biq.sdk.android.networking.models.EventDto

internal interface EventDataRepository {
    suspend fun insertAll(dtoList: List<EventDto>)
    suspend fun getAll(): List<EventDto>
    suspend fun deleteById(eventId: String)
    suspend fun deleteOlderThan(updatedAtThresholdMillis: Long)
    suspend fun deleteAll()
}
