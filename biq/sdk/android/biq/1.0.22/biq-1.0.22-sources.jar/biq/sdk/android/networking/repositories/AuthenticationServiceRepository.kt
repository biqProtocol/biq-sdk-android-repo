package biq.sdk.android.networking.repositories

import biq.sdk.android.networking.RetrofitInstance
import biq.sdk.android.networking.models.RefreshAuthRequestDto
import biq.sdk.android.networking.services.AuthenticationService

internal object AuthenticationServiceRepository {

    private val retService: AuthenticationService by lazy {
        RetrofitInstance
            .instance
            .create(AuthenticationService::class.java)
    }

    suspend fun refreshToken(refreshToken: String) = retService.doRefreshToken(
        RefreshAuthRequestDto(refreshToken)
    )
}