package biq.sdk.android.managers.bluetooth

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.os.ParcelUuid
import androidx.annotation.RequiresPermission
import biq.sdk.android.helpers.extensions.logDebugMessage
import biq.sdk.android.helpers.extensions.logWarningMessage
import biq.sdk.android.managers.bluetooth.BluetoothCommunicationManager.BEACON_UUID
import biq.sdk.android.managers.beacon.BeaconScannerManager.BeaconInfo
import biq.sdk.android.managers.beacon.BeaconScannerManager.BeaconKey
import biq.sdk.android.providers.CoroutineScopeProvider
import kotlinx.coroutines.launch
import org.altbeacon.beacon.Beacon
import java.time.LocalDateTime

internal object BluetoothScannerManager {

    private val scannerToConnect = BluetoothAdapter.getDefaultAdapter().bluetoothLeScanner

    private val expectedUUID = ParcelUuid.fromString(BEACON_UUID.toString())

    private val settings = ScanSettings.Builder()
        .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
        .build()

    private val filters = listOf(
        ScanFilter.Builder()
            .setServiceUuid(expectedUUID)
            .build()
    )

    private var isScanning = false

    data class DeviceInfo(
        val beaconKey: BeaconKey,
        val beacon: Beacon?,
        var lastValidationAt: LocalDateTime? = null,
        var publicKey: String = ""
    )

    private val _foundDevicesToConnect = mutableMapOf<String, DeviceInfo>()
    val foundDevicesToConnect: Map<String, DeviceInfo> get() = _foundDevicesToConnect

    // Tracks beacon types seen during ranging (used to validate device beacon types)
    private val _rangedBeacons = mutableMapOf<BeaconKey, BeaconInfo>()

    fun recordRangedBeacon(key: BeaconKey, beacon: Beacon) {
        _rangedBeacons.putIfAbsent(key, BeaconInfo(beacon))
    }

    /**
     * Records a device for validation by its MAC address.
     * Multiple devices with the same BeaconKey are tracked independently.
     */
    fun recordDeviceToConnect(
        macAddress: String,
        beaconKey: BeaconKey,
        beacon: Beacon? = null
    ) {
        _foundDevicesToConnect.putIfAbsent(macAddress, DeviceInfo(beaconKey, beacon))
    }

    fun updateValidatedDevice(macAddress: String) {
        _foundDevicesToConnect[macAddress]?.lastValidationAt = LocalDateTime.now()
    }

    fun resetValidatedDevices() {
        _foundDevicesToConnect.clear()
        _rangedBeacons.clear()
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    fun startScan() {
        if (!isScanning) {
            scannerToConnect.startScan(filters, settings, scanToConnectCallback)
            isScanning = true
        } else {
            "[BIQ][BSM] Scan already in progress.".logWarningMessage()
        }
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    fun stopScan() {
        if (isScanning) {
            scannerToConnect.stopScan(scanToConnectCallback)
            isScanning = false
        }
    }

    val scanToConnectCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val address = device.address
            val name = device.name ?: "Unknown"
            val uuids = result.scanRecord?.serviceUuids?.joinToString() ?: "None"

            "[BIQ][BSM] 📡 Found device: $name, $address, UUIDs: $uuids".logDebugMessage()

            if (result.scanRecord?.serviceUuids?.contains(expectedUUID) == true) {
                val beaconKey = extractBeaconKeyFromScanResult(result)
                
                // Record this device for potential validation
                if (beaconKey != null) {
                    val rangedBeacon = _rangedBeacons[beaconKey]?.beacon
                    recordDeviceToConnect(address, beaconKey, rangedBeacon)
                }
                
                "[BIQ][BSM] 🎯 Target device found, connecting to $address, beaconKey=$beaconKey".logDebugMessage()
                CoroutineScopeProvider.get().launch {
                    BluetoothCommunicationManager.handleDetectedDevice(
                        device = result.device,
                        beaconKey = beaconKey
                    )
                }
            }
        }
    }

    /**
     * Finds an available device that needs validation.
     *
     * @param macAddress The MAC address of the device to check.
     * @param devicesBeingValidated Set of MAC addresses that are currently being validated (to exclude them).
     * @param restrictionMinutes Minimum time in minutes that must pass before re-validating a device.
     * @return The DeviceInfo if available, or null if the device is not available for validation.
     */
    fun findAvailableDevice(
        macAddress: String,
        devicesBeingValidated: Set<String>,
        restrictionMinutes: Long
    ): DeviceInfo? {
        if (devicesBeingValidated.contains(macAddress)) {
            return null
        }
        
        val deviceInfo = _foundDevicesToConnect[macAddress] ?: return null
        
        val isAvailable = deviceInfo.lastValidationAt == null ||
                deviceInfo.lastValidationAt?.isBefore(
                    LocalDateTime.now().minusMinutes(restrictionMinutes)
                ) == true
        
        return if (isAvailable) deviceInfo else null
    }

    /**
     * Checks if a device with the given BeaconKey is known (from ranging).
     * This helps validate that we should process a device even if it wasn't recorded yet.
     */
    fun isKnownBeaconType(beaconKey: BeaconKey): Boolean {
        return _rangedBeacons.containsKey(beaconKey)
    }

    /**
     * Extracts iBeacon UUID/major/minor from the manufacturer specific data in the scan result.
     * Returns null if the data cannot be parsed.
     */
    private fun extractBeaconKeyFromScanResult(result: ScanResult): BeaconKey? {
        try {
            // iBeacon manufacturer ID is 0x004C (Apple)
            val manufacturerData = result.scanRecord?.getManufacturerSpecificData(0x004C) ?: return null
            
            // iBeacon format: 0x02 0x15 [16 bytes UUID] [2 bytes major] [2 bytes minor] [1 byte tx power]
            // Minimum length: 1 (type) + 1 (length) + 16 (UUID) + 2 (major) + 2 (minor) + 1 (tx) = 23 bytes
            if (manufacturerData.size < 23) return null
            
            // Check for iBeacon type (0x02) and length (0x15 = 21 bytes following)
            if (manufacturerData[0] != 0x02.toByte() || manufacturerData[1] != 0x15.toByte()) return null
            
            // Extract UUID (bytes 2-17)
            val uuidBytes = manufacturerData.copyOfRange(2, 18)
            val uuid = java.util.UUID(
                java.nio.ByteBuffer.wrap(uuidBytes.copyOfRange(0, 8)).long,
                java.nio.ByteBuffer.wrap(uuidBytes.copyOfRange(8, 16)).long
            )
            
            // Extract major (bytes 18-19)
            val major = ((manufacturerData[18].toInt() and 0xFF) shl 8) or 
                       (manufacturerData[19].toInt() and 0xFF)
            
            // Extract minor (bytes 20-21)
            val minor = ((manufacturerData[20].toInt() and 0xFF) shl 8) or 
                       (manufacturerData[21].toInt() and 0xFF)
            
            "[BIQ][BSM] Extracted iBeacon data: UUID=$uuid, major=$major, minor=$minor".logDebugMessage()
            
            return BeaconKey(uuid, major, minor)
        } catch (e: Exception) {
            "[BIQ][BSM] Failed to extract iBeacon data from scan result: ${e.message}".logWarningMessage()
            return null
        }
    }

}