package biq.sdk.android.networking.models

import biq.sdk.android.data.entities.EventAreaEntity
import biq.sdk.android.data.entities.EventEntity
import biq.sdk.android.data.entities.EventLocationEntity

internal data class PresenceProofRequestDto(
    val uuid: String,
    val major: Int,
    val minor: Int,
    val publicKey: String,
    val signature: String
)

data class PresenceProofResponseDto(
    val events: List<EventDto>
)

data class EventDto(
    val id: String,
    val type: String,
    val name: String,
    val description: String,
    val image: String,
    val organizer: String?,
    val url: String?,
    val startTime: Long?,
    val endTime: Long?,
    val isPublic: Boolean?,
    val isGated: Boolean?,
    val tags: List<String>?,
    val owners: List<String>?,
    val locations: List<EventLocationDto>?,
    val rawData: String? = null
)

data class EventLocationDto(
    val id: String,
    val name: String,
    val address: String,
    val mapLink: String,
    val beacons: List<String>?,
    val allowUserBeacons: Boolean?,
    val geofence: GeofenceDto?,
    val areas: List<EventAreaDto>?
)

data class GeofenceDto(
    val lat: Double?,
    val lng: Double?,
    val radius: Double?
)

data class EventAreaDto(
    val id: String,
    val name: String,
    val description: String,
    val image: String,
    val beacons: List<String>?
)

internal fun EventDto.toEntity(updatedAt: Long) = EventEntity(
    id = id,
    type = type,
    name = name,
    description = description,
    image = image,
    organizer = organizer,
    url = url,
    startTime = startTime,
    endTime = endTime,
    isPublic = isPublic,
    isGated = isGated,
    tags = tags,
    owners = owners,
    rawData = rawData,
    updatedAt = updatedAt
)

internal fun EventLocationDto.toEntity(eventId: String) = EventLocationEntity(
    id = id,
    eventId = eventId,
    name = name,
    address = address,
    mapLink = mapLink,
    beacons = beacons,
    allowUserBeacons = allowUserBeacons,
    lat = geofence?.lat,
    lng = geofence?.lng,
    radius = geofence?.radius
)

internal fun EventAreaDto.toEntity(locationId: String) = EventAreaEntity(
    id = id,
    locationId = locationId,
    name = name,
    description = description,
    image = image,
    beacons = beacons
)
