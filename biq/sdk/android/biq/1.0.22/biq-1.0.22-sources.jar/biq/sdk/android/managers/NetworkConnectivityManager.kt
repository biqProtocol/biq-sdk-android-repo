package biq.sdk.android.managers

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import biq.sdk.android.BiqController
import biq.sdk.android.helpers.extensions.logDebugMessage
import biq.sdk.android.helpers.extensions.logErrorMessage
import biq.sdk.android.models.BiqNetworkState
import biq.sdk.android.providers.ConnectionStateProvider
import biq.sdk.android.providers.ContextProvider

object NetworkConnectivityManager {
    fun isConnected(): Boolean {
        val connectivityManager = ContextProvider.get().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork = connectivityManager.activeNetwork ?: return false
        val networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
        return networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}
