package biq.sdk.android.providers

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

internal object CoroutineScopeProvider {

    @Volatile
    private var beaconScope: CoroutineScope? = null

    fun init() {
        if (beaconScope == null) {
            synchronized(this) {
                if (beaconScope == null) {
                    beaconScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
                }
            }
        }
    }

    fun destroy() {
        synchronized(this) {
            beaconScope?.cancel()
            beaconScope = null
        }
    }

    /***
     * For longer-running or looping coroutines (e.g., periodic ranging), consider checking isActive
     */
    fun get(): CoroutineScope {
        return beaconScope ?: synchronized(this) {
            beaconScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
            beaconScope!!
        }
    }
}
