package biq.sdk.android.data.entities.relations

import androidx.room.Embedded
import androidx.room.Relation
import biq.sdk.android.data.entities.EventAreaEntity
import biq.sdk.android.data.entities.EventLocationEntity
import biq.sdk.android.data.entities.toDto
import biq.sdk.android.networking.models.EventLocationDto
import biq.sdk.android.networking.models.GeofenceDto

data class LocationWithAreas(
    @Embedded val location: EventLocationEntity,
    @Relation(
        parentColumn = EventLocationEntity.COLUMN_ID,
        entityColumn = EventAreaEntity.COLUMN_LOCATION_ID
    )
    val areas: List<EventAreaEntity>
)

fun LocationWithAreas.toDto() = EventLocationDto(
    id = location.id,
    name = location.name,
    address = location.address,
    mapLink = location.mapLink,
    beacons = location.beacons,
    allowUserBeacons = location.allowUserBeacons,
    geofence = GeofenceDto(
        lat = location.lat,
        lng = location.lng,
        radius = location.radius
    ),
    areas = areas.map { it.toDto() }
)