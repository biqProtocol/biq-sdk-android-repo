package biq.sdk.android.helpers.extensions

import android.util.Log
import biq.sdk.android.managers.LogLevel
import biq.sdk.android.managers.LogsManager
import biq.sdk.android.providers.DebugModeProvider

internal fun String.logErrorMessage(tag: String = "", isForced: Boolean = false) {
    if (DebugModeProvider.isDebugOn  || isForced) {
        Log.e(tag, this)
        LogsManager.recordLog(LogLevel.ERROR, tag, this)
    }
}

internal fun String.logDebugMessage(tag: String = "") {
    if (DebugModeProvider.isDebugOn) {
        Log.d(tag, this)
        LogsManager.recordLog(LogLevel.DEBUG, tag, this)
    }
}

internal fun String.logWarningMessage(tag: String = "") {
    if (DebugModeProvider.isDebugOn) {
        Log.w(tag, this)
        LogsManager.recordLog(LogLevel.WARNING, tag, this)
    }
}

internal fun String.logInfoMessage(tag: String = "") {
    if (DebugModeProvider.isDebugOn) {
        Log.i(tag, this)
        LogsManager.recordLog(LogLevel.INFO, tag, this)
    }
}
