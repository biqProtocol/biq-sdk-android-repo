/**
 * Automatically generated file. DO NOT MODIFY
 */
package biq.sdk.android;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "biq.sdk.android";
  public static final String BUILD_TYPE = "release";
}
