package biq.sdk.android.networking.services

import biq.sdk.android.networking.models.RefreshAuthRequestDto
import biq.sdk.android.networking.models.RefreshAuthResponseDto
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

internal interface AuthenticationService {
    @POST("api/protocol/v0/auth/refresh")
    suspend fun doRefreshToken(@Body model: RefreshAuthRequestDto): Response<RefreshAuthResponseDto>
}