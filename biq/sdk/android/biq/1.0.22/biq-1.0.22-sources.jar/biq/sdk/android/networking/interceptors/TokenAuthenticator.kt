package biq.sdk.android.networking.interceptors

import biq.sdk.android.BiqController
import biq.sdk.android.networking.repositories.AuthenticationServiceRepository
import biq.sdk.android.providers.UserSessionProvider
import kotlinx.coroutines.runBlocking
import okhttp3.Authenticator
import okhttp3.Request
import okhttp3.Response
import okhttp3.Route
import java.io.IOException

internal class TokenAuthenticator() : Authenticator {

    override fun authenticate(route: Route?, response: Response): Request? {
        if (responseCount(response) >= 2) return null

        var refreshFailureCount = 0

        val newToken = runBlocking {
            repeat(3) {
                try {
                    val refreshToken = UserSessionProvider.getRefresh() ?: return@runBlocking null

                    val refreshResponse = AuthenticationServiceRepository.refreshToken(refreshToken)

                    when (refreshResponse.isSuccessful) {
                        true -> {
                            val body = refreshResponse.body()
                            body?.let {
                                UserSessionProvider.set(it.idToken)
                                return@runBlocking it.idToken
                            }

                            // Parsing error (no body): count as failure
                            refreshFailureCount++
                        }

                        else -> if (refreshResponse.code() in listOf(401)) {
                            // Unauthorized, invalid api key or expired token: count as failure
                            refreshFailureCount++
                        }
                    }
                } catch (e: IOException) {
                    // Network error: don't count this as failure
                    e.printStackTrace()
                    return@runBlocking null
                } catch (e: Exception) {
                    // Unknown / unexpected error: count as failure
                    e.printStackTrace()
                    refreshFailureCount++
                }
            }

            if (refreshFailureCount >= 3) {
                BiqController.getInstance().logOut()
            }

            return@runBlocking null
        }

        return newToken?.let {
            response.request.newBuilder()
                .header(
                    name = SessionAuthInterceptor.AUTHORIZATION,
                    value = "${SessionAuthInterceptor.BEARER} $it"
                )
                .build()
        }
    }

    private fun responseCount(response: Response): Int {
        var count = 1
        var res = response.priorResponse
        while (res != null) {
            count++
            res = res.priorResponse
        }
        return count
    }
}

