package biq.sdk.android.helpers

import biq.sdk.android.models.BiqPresenceState

sealed class ConnectionState {
    data class Success(
        val state: BiqPresenceState? = null
    ) : ConnectionState()

    data class Error(
        val exception: Throwable? = null,
        val message: String? = null,
        val state: BiqPresenceState? = null
    ) : ConnectionState()

    data class MissingPermission(
        val permission: String
    ) : ConnectionState()

}