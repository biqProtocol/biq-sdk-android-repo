package biq.sdk.android.data.repositories.event

import biq.sdk.android.data.dao.EventAreaDao
import biq.sdk.android.data.dao.EventDao
import biq.sdk.android.data.dao.EventLocationDao
import biq.sdk.android.data.entities.EventAreaEntity
import biq.sdk.android.data.entities.EventLocationEntity
import biq.sdk.android.data.entities.relations.toDto
import biq.sdk.android.managers.event.EventCleanupScheduler
import biq.sdk.android.networking.models.EventDto
import biq.sdk.android.networking.models.toEntity

internal class EventDataRepositoryLocal(
    private val eventDao: EventDao,
    private val eventLocationDao: EventLocationDao,
    private val eventAreaDao: EventAreaDao
) : EventDataRepository {
    override suspend fun insertAll(dtoList: List<EventDto>) {
        dtoList.forEach { event ->
            val locations = mutableListOf<EventLocationEntity>()
            val areas = mutableListOf<EventAreaEntity>()

            event.locations?.forEach { location ->
                location.areas?.map { area ->
                    area.toEntity(location.id)
                }?.let { areas.addAll(it) }
                locations.add(location.toEntity(event.id))
            }

            deleteById(event.id) // Remove stale data for this event before upserting
            eventDao.insertAll(listOf(event.toEntity(System.currentTimeMillis())))
            if (locations.isNotEmpty()) {
                eventLocationDao.insertAll(locations)
            }
            if (areas.isNotEmpty()) {
                eventAreaDao.insertAll(areas)
            }
            EventCleanupScheduler.scheduleCleanup(event.id)
        }
    }

    override suspend fun getAll() = eventDao.getEventsWithLocationsAndAreas().map { it.toDto() }

    override suspend fun deleteById(eventId: String) {
        eventAreaDao.deleteByEventId(eventId)
        eventLocationDao.deleteByEventId(eventId)
        eventDao.deleteById(eventId)
    }

    override suspend fun deleteOlderThan(updatedAtThresholdMillis: Long) {
        val staleIds = eventDao.getIdsOlderThan(updatedAtThresholdMillis)
        if (staleIds.isEmpty()) return

        eventAreaDao.deleteByEventIds(staleIds)
        eventLocationDao.deleteByEventIds(staleIds)
        eventDao.deleteByIds(staleIds)
    }

    override suspend fun deleteAll() {
        eventDao.deleteAll()
        eventLocationDao.deleteAll()
        eventAreaDao.deleteAll()
    }
}
