package biq.sdk.android.managers

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.TaskStackBuilder
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import biq.sdk.android.R
import biq.sdk.android.managers.preferences.PrefsManager
import biq.sdk.android.providers.ContextProvider
import biq.sdk.android.providers.CoroutineScopeProvider
import kotlinx.coroutines.launch

// TODO create builder to configure the notification
internal object NotificationsManager {

    private const val BIQ_SCANNING_CHANNEL_ID = "biq_scanning_channel"
    const val BIQ_SCANNING_NOTIFICATION_ID = 24680
    private const val BIQ_ALERTS_CHANNEL_ID = "biq_alerts_channel"
    private const val BIQ_NEARBY_NOTIFICATION_ID = 13579

    private const val BIQ_SCANNING_NOTIFICATION_TITLE_DEFAULT = "Biq SDK"
    private const val BIQ_SCANNING_NOTIFICATION_MESSAGE_DEFAULT = "Scanning for Beacons."

    private const val BIQ_PROXIMITY_NOTIFICATION_TITLE_DEFAULT = "Biq SDK"
    private const val BIQ_PROXIMITY_NOTIFICATION_MESSAGE_DEFAULT = "A beacon is nearby."

    private val BIQ_NOTIFICATION_ICON = R.drawable.ic_launcher_background

    private var scanningNotificationTitle: String = BIQ_SCANNING_NOTIFICATION_TITLE_DEFAULT
    private var scanningNotificationMessage: String = BIQ_SCANNING_NOTIFICATION_MESSAGE_DEFAULT

    private var proximityNotificationTitle: String = BIQ_PROXIMITY_NOTIFICATION_TITLE_DEFAULT
    private var proximityNotificationMessage: String = BIQ_PROXIMITY_NOTIFICATION_MESSAGE_DEFAULT

    private var iconResId: Int = BIQ_NOTIFICATION_ICON

    private var targetActivityClass: Class<out Activity>? = null

    fun configure(targetActivity: Class<out Activity>) {
        targetActivityClass = targetActivity
    }

    fun initNotificationData(
        iconResId: Int?,
        scanningNotificationTitle: String?,
        scanningNotificationMessage: String?,
        proximityNotificationTitle: String?,
        proximityNotificationMessage: String?
    ) = CoroutineScopeProvider.get().launch {
        this@NotificationsManager.iconResId = iconResId?.let {
            try {
                ContextProvider.get().resources.getResourceName(iconResId)
                iconResId
            } catch (e: Exception) {
                this@NotificationsManager.iconResId
            }
        } ?: BIQ_NOTIFICATION_ICON

        this@NotificationsManager.scanningNotificationTitle =
            scanningNotificationTitle ?: BIQ_SCANNING_NOTIFICATION_TITLE_DEFAULT
        this@NotificationsManager.scanningNotificationMessage =
            scanningNotificationMessage ?: BIQ_SCANNING_NOTIFICATION_MESSAGE_DEFAULT

        this@NotificationsManager.proximityNotificationTitle =
            proximityNotificationTitle ?: BIQ_PROXIMITY_NOTIFICATION_TITLE_DEFAULT
        this@NotificationsManager.proximityNotificationMessage =
            proximityNotificationMessage ?: BIQ_PROXIMITY_NOTIFICATION_MESSAGE_DEFAULT

        PrefsManager.saveNotificationIcon(this@NotificationsManager.iconResId)

        PrefsManager.saveScanningNotificationTitle(this@NotificationsManager.scanningNotificationTitle)
        PrefsManager.saveScanningNotificationMessage(this@NotificationsManager.scanningNotificationMessage)

        PrefsManager.saveProximityNotificationTitle(this@NotificationsManager.proximityNotificationTitle)
        PrefsManager.saveProximityNotificationMessage(this@NotificationsManager.proximityNotificationMessage)
    }

    fun loadNotificationData() = CoroutineScopeProvider.get().launch {
        this@NotificationsManager.iconResId = PrefsManager.getNotificationIcon()?.let { iconResId ->
            try {
                ContextProvider.get().resources.getResourceName(iconResId)
                iconResId
            } catch (e: Exception) {
                this@NotificationsManager.iconResId
            }
        } ?: BIQ_NOTIFICATION_ICON

        scanningNotificationTitle =
            PrefsManager.getScanningNotificationTitle() ?: BIQ_SCANNING_NOTIFICATION_TITLE_DEFAULT
        scanningNotificationMessage = PrefsManager.getScanningNotificationMessage()
            ?: BIQ_SCANNING_NOTIFICATION_MESSAGE_DEFAULT

        proximityNotificationTitle =
            PrefsManager.getProximityNotificationTitle() ?: BIQ_PROXIMITY_NOTIFICATION_TITLE_DEFAULT
        proximityNotificationMessage = PrefsManager.getProximityNotificationMessage()
            ?: BIQ_PROXIMITY_NOTIFICATION_MESSAGE_DEFAULT
    }

    fun getScanningForegroundNotification(): Notification {
        val builder = NotificationCompat.Builder(ContextProvider.get(), BIQ_SCANNING_CHANNEL_ID)
            .setContentTitle(scanningNotificationTitle)
            .setSmallIcon(iconResId)
            .setContentText(scanningNotificationMessage)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setSound(null)
            .setVibrate(null)
            .setAutoCancel(false)
            .setOngoing(true)

        targetActivityClass?.let { activityClass ->
            val intent = Intent(ContextProvider.get(), activityClass)

            val pendingIntent = PendingIntent.getActivity(
                ContextProvider.get(),
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT + PendingIntent.FLAG_IMMUTABLE
            )
            builder.setContentIntent(pendingIntent);
        }

        val channel = NotificationChannel(
            BIQ_SCANNING_CHANNEL_ID,
            "My Notification Name",
            NotificationManager.IMPORTANCE_LOW
        )
        channel.description = "Notification related to ongoing beacon scanning"
        channel.setSound(null, null)
        channel.enableVibration(false)

        val notificationManager = ContextProvider.get().getSystemService(
            Context.NOTIFICATION_SERVICE
        ) as NotificationManager
        notificationManager.createNotificationChannel(channel)
        builder.setChannelId(channel.id)

        val notification = builder.build()
        return notification
    }

    fun cancelScanningNotification() {
        NotificationManagerCompat.from(ContextProvider.get()).cancel(BIQ_SCANNING_NOTIFICATION_ID)
    }

    fun sendNearbyNotification() = CoroutineScopeProvider.get().launch {
        val isNotificationAvailable = PrefsManager.getNotificationAvailabilityPreference()
        if (!isNotificationAvailable) return@launch

        triggerNearbyNotification()
    }

    private fun triggerNearbyNotification() {
        val builder =
            NotificationCompat.Builder(ContextProvider.get(), BIQ_ALERTS_CHANNEL_ID)
                .setContentTitle(proximityNotificationTitle)
                .setContentText(proximityNotificationMessage)
                .setSmallIcon(iconResId)

        targetActivityClass?.let { activityClass ->
            val intent = Intent(ContextProvider.get(), activityClass)
            val stackBuilder = TaskStackBuilder.create(ContextProvider.get())
            stackBuilder.addNextIntent(intent)

            val resultPendingIntent = stackBuilder.getPendingIntent(
                0,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            builder.setContentIntent(resultPendingIntent)
        }

        val channel = NotificationChannel(
            BIQ_ALERTS_CHANNEL_ID,
            "My Notification Name",
            NotificationManager.IMPORTANCE_DEFAULT
        )
        channel.description = "My Notification Channel Description"

        val notificationManager = ContextProvider.get().getSystemService(
            Context.NOTIFICATION_SERVICE
        ) as NotificationManager
        notificationManager.createNotificationChannel(channel);
        builder.setChannelId(channel.id);
        notificationManager.notify(BIQ_NEARBY_NOTIFICATION_ID, builder.build())
    }

    fun cancelNearbyNotification() {
        NotificationManagerCompat.from(ContextProvider.get()).cancel(BIQ_NEARBY_NOTIFICATION_ID)
    }
}