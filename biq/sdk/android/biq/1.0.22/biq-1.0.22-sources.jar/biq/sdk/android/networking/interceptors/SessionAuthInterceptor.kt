package biq.sdk.android.networking.interceptors

import biq.sdk.android.providers.UserSessionProvider
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.Response

internal class SessionAuthInterceptor : Interceptor {

    companion object {
        const val AUTHORIZATION: String = "Authorization"
        const val BEARER = "Bearer"
    }

    override fun intercept(chain: Interceptor.Chain): Response {
        val authToken = runBlocking {
            UserSessionProvider.get()
        }

        val request = chain
            .request()
            .newBuilder()

        when (authToken.isNullOrEmpty()) {
            false -> request.addHeader(AUTHORIZATION, "$BEARER $authToken")
            else -> Unit
        }

        return chain.proceed(
            request.build()
        )
    }
}