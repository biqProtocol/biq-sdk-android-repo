package biq.sdk.android.managers.preferences

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import biq.sdk.android.BuildConfig
import biq.sdk.android.providers.ContextProvider
import biq.sdk.android.providers.DebugModeProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.time.LocalDateTime

// Create extension to get DataStore instance
private val Context.debugDataStore by preferencesDataStore(name = "biq_sdk_debug_prefs")

internal object DebugPrefsManager {

    private const val VALIDATION_TIMESTAMPS_KEY = "validationTimestamps"
    private const val BOOT_TIMESTAMPS_KEY = "bootTimestamps"

    private val context: Context get() = ContextProvider.get()

    private suspend fun writeString(key: String, value: String) = withContext(Dispatchers.IO) {
        context.debugDataStore.edit { prefs ->
            prefs[stringPreferencesKey(key)] = value
        }
    }

    private suspend fun readString(key: String): String? = withContext(Dispatchers.IO) {
        val prefKey = stringPreferencesKey(key)
        val prefs = context.debugDataStore.data.first()
        prefs[prefKey]
    }

    private suspend fun remove(key: String) = withContext(Dispatchers.IO) {
        context.debugDataStore.edit { prefs ->
            prefs.remove(stringPreferencesKey(key))
        }
    }

    suspend fun saveValidationStateTimestamp(isStarted: Boolean, isSuccess: Boolean? = null) {
        if(DebugModeProvider.isDebugOff) {
            return
        }

        val current = readString(VALIDATION_TIMESTAMPS_KEY) ?: ""
        val infoToAdd = when(isStarted) {
            true -> "${LocalDateTime.now()}-->validation started"
            false -> when(isSuccess) {
                true -> "${LocalDateTime.now()}-->validation finished & SUCCEEDED"
                else -> "${LocalDateTime.now()}-->validation finished & FAILED"
            }
        }

        val new = when(current.isEmpty()) {
            true -> infoToAdd
            false -> "$current, $infoToAdd"
        }

        writeString(VALIDATION_TIMESTAMPS_KEY, new)
    }

    suspend fun saveValidationTimestamp(signatureIds: String) {
        if(DebugModeProvider.isDebugOff) {
            return
        }

        val current = readString(VALIDATION_TIMESTAMPS_KEY) ?: ""
        val new = when(current.isEmpty()) {
            true -> "${LocalDateTime.now()}-->signatures:$signatureIds"
            false -> "$current, ${LocalDateTime.now()}-->signatures:$signatureIds"
        }

        writeString(VALIDATION_TIMESTAMPS_KEY, new)
    }

    suspend fun saveValidationLog(log: String) {
        if(DebugModeProvider.isDebugOff) {
            return
        }

        val current = readString(VALIDATION_TIMESTAMPS_KEY) ?: ""
        val new = when(current.isEmpty()) {
            true -> log
            false -> "$current, $log"
        }

        writeString(VALIDATION_TIMESTAMPS_KEY, new)
    }

    suspend fun getValidationsRecords(): String? {
        val records = readString(VALIDATION_TIMESTAMPS_KEY)?.replace(", ", "\n")
        return records
    }

    suspend fun removeValidationsRecords() = remove(VALIDATION_TIMESTAMPS_KEY)

    suspend fun saveBootLoadedStates(isSuccess: Boolean) {
        if(DebugModeProvider.isDebugOff) {
            return
        }

        val current = readString(BOOT_TIMESTAMPS_KEY) ?: ""
        val new = when(current.isEmpty()) {
            true -> "${LocalDateTime.now()}-->bootState=$isSuccess"
            false -> "$current, ${LocalDateTime.now()}-->bootState=$isSuccess"
        }

        writeString(BOOT_TIMESTAMPS_KEY, new)
    }
}