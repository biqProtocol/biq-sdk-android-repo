package biq.sdk.android.managers.location

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.location.LocationManager
import androidx.core.content.ContextCompat
import biq.sdk.android.BiqController
import biq.sdk.android.helpers.extensions.logErrorMessage
import biq.sdk.android.models.BiqPresenceState
import biq.sdk.android.providers.ConnectionStateProvider

internal object LocationStateManager {

    @Volatile
    private var lastKnownLocationState: Boolean? = null

    private val locationStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == LocationManager.PROVIDERS_CHANGED_ACTION) {
                val isLocationEnabled = BiqController.getInstance().isLocationEnabled()
                
                // Only process if the state actually changed to avoid duplicate events
                if (lastKnownLocationState == isLocationEnabled) {
                    return
                }
                
                lastKnownLocationState = isLocationEnabled
                
                BiqController.getInstance().notifyLocationStateChange(isLocationEnabled)

                if (!isLocationEnabled) {
                    if (!ConnectionStateProvider.scanningState.didNotStart) {
                        ConnectionStateProvider.updateState(BiqPresenceState.SCANNING_PAUSED)
                    }
                    "[BIQ] Location OFF".logErrorMessage()
                } else {
                    if (!ConnectionStateProvider.scanningState.didNotStart) {
                        if (BiqController.getInstance().areRequiredServicesEnabled()) {
                            ConnectionStateProvider.updateState(BiqPresenceState.SCANNING_IN_PROGRESS)
                        }
                    }
                    "[BIQ] Location ON".logErrorMessage()
                }
            }
        }
    }

    private var isRegistered = false

    fun register(context: Context) {
        if (!isRegistered) {
            // Initialize the last known state when registering
            lastKnownLocationState = BiqController.getInstance().isLocationEnabled()
            
            val filter = IntentFilter(LocationManager.PROVIDERS_CHANGED_ACTION)
            ContextCompat.registerReceiver(
                context.applicationContext,
                locationStateReceiver,
                filter,
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            isRegistered = true
        }
    }

    fun unregister(context: Context) {
        if (isRegistered) {
            context.applicationContext.unregisterReceiver(locationStateReceiver)
            isRegistered = false
            lastKnownLocationState = null
        }
    }
}

