package biq.sdk.android.models

enum class BiqScanningState(val id: Int) {
    UNKNOWN(0),
    SCANNING_NOT_STARTED(1),
    SCANNING_IN_PROGRESS(2),
    SCANNING_PAUSED(3);

    val didNotStart
        get() = this == UNKNOWN || this == SCANNING_NOT_STARTED
}