package biq.sdk.android.providers

import biq.sdk.android.managers.preferences.EncryptedPrefsManager

internal object UserSessionProvider {
    suspend fun init(apiKey: String, refreshToken: String) {
        EncryptedPrefsManager.saveApiKey(apiKey)
        EncryptedPrefsManager.saveRefreshToken(refreshToken)
    }

    suspend fun set(idToken: String?) {
        when(idToken) {
            null -> EncryptedPrefsManager.removeAccessToken()
            else -> EncryptedPrefsManager.saveAccessToken(idToken)
        }
    }

    suspend fun logout() {
        EncryptedPrefsManager.removeAccessToken()
        EncryptedPrefsManager.removeApiKey()
        EncryptedPrefsManager.removeRefreshToken()
    }

    suspend fun get() = EncryptedPrefsManager.getAccessToken()
    suspend fun getApi() = EncryptedPrefsManager.getApiKey()
    suspend fun getRefresh() = EncryptedPrefsManager.getRefreshToken()
}
