package biq.sdk.android.networking.interceptors

import biq.sdk.android.providers.UserSessionProvider
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.Response

internal class ApiKeyInterceptor : Interceptor {

    companion object {
        const val KEY: String = "x-api-key"
    }

    override fun intercept(chain: Interceptor.Chain): Response {
        val apiKey = runBlocking {
            UserSessionProvider.getApi()
        }

        val request = chain
            .request()
            .newBuilder()

        when (apiKey.isNullOrEmpty()) {
            false -> request.addHeader(KEY, apiKey)
            else -> Unit
        }

        return chain.proceed(
            request.build()
        )
    }
}