package biq.sdk.android.helpers.extensions

fun String.isApiKeyValid() = this.length == 24
fun String.isApiKeyNotValid() = !this.isApiKeyValid()

fun String.isRefreshTokenValid() = this.length == 64
fun String.isRefreshTokenNotValid() = !this.isRefreshTokenValid()