package biq.sdk.android.managers.beacon

import android.annotation.SuppressLint
import androidx.lifecycle.Observer
import biq.sdk.android.BiqController
import biq.sdk.android.BuildConfig
import biq.sdk.android.helpers.ConnectionState
import biq.sdk.android.helpers.extensions.logDebugMessage
import biq.sdk.android.managers.NetworkConnectivityManager
import biq.sdk.android.managers.NotificationsManager
import biq.sdk.android.managers.PermissionsManager
import biq.sdk.android.managers.bluetooth.BluetoothCommunicationManager
import biq.sdk.android.managers.bluetooth.BluetoothScannerManager
import biq.sdk.android.managers.preferences.DebugPrefsManager
import biq.sdk.android.models.BiqPresenceState
import biq.sdk.android.providers.ConnectionStateProvider
import biq.sdk.android.providers.ContextProvider
import biq.sdk.android.providers.CoroutineScopeProvider
import biq.sdk.android.providers.DatabaseProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.altbeacon.beacon.Beacon
import org.altbeacon.beacon.BeaconManager
import org.altbeacon.beacon.MonitorNotifier
import org.altbeacon.beacon.Settings
import java.time.LocalDateTime
import java.util.UUID

internal class BeaconScannerManager() {

    companion object {
        const val TAG = "BeaconScannerManager"

        /***
         * Maximum time allowed, in milliseconds, inside a beacon region.
         */
        const val RANGE_INSIDE_MILLIS = 10_000L

        /***
         * Rerun ranging every N minutes inside a beacon region.
         */
        const val RANGING_LOOP_MINUTES = 5L

        /***
         * Prevent a validation to happen more than N minutes after the last one.
         */
        const val VALIDATION_RESTRICTION_MINUTES = 4L
    }

    private val beaconUtils = BeaconUtils()

    private var beaconManager: BeaconManager? = null
    private var isScanning = false

    private var rangingLoopJob: Job? = null

    data class BeaconKey(
        val uuid: UUID,
        val major: Int,
        val minor: Int
    )

    data class BeaconInfo(
        val beacon: Beacon,
        var lastValidationAt: LocalDateTime? = null,
        var publicKey: String = ""
    )

    @SuppressLint("MissingPermission")
    private val centralMonitoringObserver = Observer<Int> { state ->
        "[BIQ][BSM] centralMonitoringObserver state: $state".logDebugMessage()

        if (state == MonitorNotifier.OUTSIDE) {
            beaconUtils.onMonitorNotifier(state)
            rangingLoopJob?.cancel()

            "[BIQ][BSM] Outside beacon region.".logDebugMessage(TAG)
            beaconUtils.stopRangingBeacons()
            BluetoothScannerManager.stopScan()

            ConnectionStateProvider.updateState(BiqPresenceState.SCANNING_IN_PROGRESS)
        } else {
            if (!beaconUtils.isInsideRegion) {
                beaconUtils.onMonitorNotifier(state)

                "[BIQ][BSM] Inside beacon region.".logDebugMessage(TAG)
                startRangingLoop()

                ConnectionStateProvider.updateState(BiqPresenceState.INSIDE_BEACON_RANGE)

                NotificationsManager.sendNearbyNotification()
            }
        }
    }

    @SuppressLint("MissingPermission")
    private val centralRangingObserver = Observer<Collection<Beacon>> { beacons ->
        "[BIQ][BSM] Ranged: ${beacons.count()} beacons".logDebugMessage(TAG)

        for (beacon: Beacon in beacons) {
            "[BIQ][BSM] Found beacon: $beacon about ${beacon.distance} meters away".logDebugMessage(
                TAG
            )
            val beaconId = beacon.id1.toUuid()
            if (BluetoothCommunicationManager.BEACON_UUID == beaconId) {
                BluetoothScannerManager.apply {
                    recordBeaconToConnect(
                        key = BeaconKey(
                            uuid = beacon.id1.toUuid(),
                            major = beacon.id2.toInt(),
                            minor = beacon.id3.toInt()
                        ),
                        beacon = beacon
                    )

                    startScan()
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startRangingLoop() {
        rangingLoopJob?.cancel()

        rangingLoopJob = CoroutineScopeProvider.get().launch {
            do {
                withContext(Dispatchers.Main) {
                    "[BIQ][BSM] Attemp ranging for beacons.".apply {
                        logDebugMessage(TAG)
                        DebugPrefsManager.saveValidationLog(this)
                    }

                    beaconUtils.startRangingBeacons()
                }

                delay(RANGE_INSIDE_MILLIS)

                withContext(Dispatchers.Main) {
                    "[BIQ][BSM] Stopping ranging after ${RANGE_INSIDE_MILLIS / 1000L} seconds or because of a network error".apply {
                        logDebugMessage(TAG)
                        DebugPrefsManager.saveValidationLog(this)
                    }

                    pauseScanning()
                }

                when (BuildConfig.DEBUG) {
                    true -> when(NetworkConnectivityManager.isConnected()){
                        true -> delay(2L * 60 * 1000L)
                        false -> delay(1L * 60 * 1000L)
                    }
                    else -> when(NetworkConnectivityManager.isConnected()){
                        true -> delay(RANGING_LOOP_MINUTES * 60 * 1000L)
                        false -> delay(1L * 60 * 1000L)
                    }
                }

            } while (beaconUtils.isInsideRegion && isActive)
        }
    }

    @SuppressLint("MissingPermission")
    fun pauseScanning() {
        beaconUtils.stopRangingBeacons()
        beaconUtils.resetRegionMonitorState()
        BluetoothScannerManager.stopScan()
    }

    fun resumeScanning(isForced: Boolean): Boolean {
        if(!isScanning) return false

        BluetoothScannerManager.resetValidatedBeacons()

        if (beaconUtils.isInsideRegion || isForced) {
            startRangingLoop()
            return true
        }

        return false
    }

    @SuppressLint("MissingPermission")
    fun startScanning(): ConnectionState {
        if (!NetworkConnectivityManager.isConnected()) {
            return ConnectionState.Error(
                state = BiqPresenceState.NETWORK_ERROR
            )
        }

        if(!BiqController.getInstance().isBluetoothEnabled()) {
            return ConnectionState.Error(
                state = BiqPresenceState.BLUETOOTH_ERROR
            )
        }

        if (isScanning) {
            return ConnectionState.Error(
                state = BiqPresenceState.SCANNING_IN_PROGRESS
            )
        }

        PermissionsManager.getMissingPermission()?.let {
            ConnectionStateProvider.updateState(BiqPresenceState.PERMISSION_ERROR)
            return ConnectionState.MissingPermission(it)
        }

        isScanning = true
        setupBeaconScanning()

        ConnectionStateProvider.updateState(BiqPresenceState.SCANNING_IN_PROGRESS)
        return ConnectionState.Success(
            state = BiqPresenceState.SCANNING_IN_PROGRESS
        )
    }

    @SuppressLint("MissingPermission")
    fun stopScanning() {
        CoroutineScopeProvider.get().launch {
            BluetoothScannerManager.stopScan()

            beaconUtils.stopMonitoringBeacon()
            beaconUtils.stopRangingBeacons()

            DatabaseProvider.getEventRepository().deleteAll()
            BiqController.getInstance().notifyValidationRecordsChange(listOf())

            withContext(Dispatchers.Main) {
                BeaconManager.getInstanceForApplication(ContextProvider.get())
                    .getRegionViewModel(beaconUtils.iBeaconRegion).apply {
                        this.regionState.removeObserver(centralMonitoringObserver)
                        this.rangedBeacons.removeObserver(centralRangingObserver)
                    }
            }

            beaconManager?.apply {
                this.removeAllMonitorNotifiers()
                this.removeAllRangeNotifiers()
            }

            NotificationsManager.cancelScanningNotification()

            isScanning = false

            ConnectionStateProvider.updateState(BiqPresenceState.SCANNING_NOT_STARTED)

            CoroutineScopeProvider.destroy()
        }
    }

    private fun setupBeaconScanning() {
        val beaconManager = BeaconManager.getInstanceForApplication(ContextProvider.get())

        val settings = getForegroundServiceScanningSettings()
        beaconManager.replaceSettings(settings)
//        beaconManager.adjustSettings(Settings(debug = true))

        beaconUtils.startMonitoringBeacon()

        CoroutineScopeProvider.get().launch {
            withContext(Dispatchers.Main) {
                val regionViewModel =
                    BeaconManager.getInstanceForApplication(ContextProvider.get())
                        .getRegionViewModel(beaconUtils.iBeaconRegion)
                // observer will be called each time the monitored regionState changes (inside vs. outside region)
                regionViewModel.regionState.observeForever(centralMonitoringObserver)
                // observer will be called each time a new list of beacons is ranged (typically ~1 second in the foreground)
                regionViewModel.rangedBeacons.observeForever(centralRangingObserver)
            }
        }

        this.beaconManager = beaconManager
    }

    private fun getForegroundServiceScanningSettings() = Settings(
        scanStrategy = Settings.ForegroundServiceScanStrategy(
            NotificationsManager.getScanningForegroundNotification(),
            NotificationsManager.BIQ_SCANNING_NOTIFICATION_ID
        ),
        scanPeriods = Settings.ScanPeriods(
            1100,
            0,
            1100,
            0
        ),
        longScanForcingEnabled = true
    )
}