package biq.sdk.android.models

enum class BiqPresenceState(id: Int) {
    UNKNOWN(0),
    SCANNING_NOT_STARTED(1),
    SCANNING_IN_PROGRESS(2),
    INSIDE_BEACON_RANGE(3),
    VALIDATION_IN_PROGRESS(4),
    PERMISSION_ERROR(5),
    NETWORK_ERROR(6),
    BLUETOOTH_ERROR(7),
    SCANNING_PAUSED(8)
}