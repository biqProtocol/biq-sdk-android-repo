package biq.sdk.android.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import biq.sdk.android.data.entities.EventAreaEntity

@Dao
internal interface EventAreaDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(areas: List<EventAreaEntity>)
    
    @Query("DELETE FROM eventAreaEntity")
    suspend fun deleteAll()

}