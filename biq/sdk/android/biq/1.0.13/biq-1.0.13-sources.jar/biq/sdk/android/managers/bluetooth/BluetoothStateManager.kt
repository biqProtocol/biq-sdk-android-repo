package biq.sdk.android.managers.bluetooth

import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.core.content.ContextCompat
import biq.sdk.android.BiqController
import biq.sdk.android.helpers.ConnectionState
import biq.sdk.android.helpers.extensions.logErrorMessage
import biq.sdk.android.models.BiqPresenceState
import biq.sdk.android.providers.ConnectionStateProvider

internal object BluetoothStateManager {

    private val btStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
            when (state) {
                BluetoothAdapter.STATE_OFF -> {
                    BiqController.getInstance().notifyBluetoothStateChange(false)

                    if(!ConnectionStateProvider.scanningState.didNotStart) {
                        ConnectionStateProvider.updateState(BiqPresenceState.SCANNING_PAUSED)
                    }
                    "[BIQ] Bluetooth OFF".logErrorMessage()
                }
                BluetoothAdapter.STATE_ON -> {
                    BiqController.getInstance().notifyBluetoothStateChange(true)

                    if(!ConnectionStateProvider.scanningState.didNotStart) {
                        ConnectionStateProvider.updateState(BiqPresenceState.SCANNING_IN_PROGRESS)
                    }
                    "[BIQ] Bluetooth ON".logErrorMessage()
                }
            }
        }
    }

    private var isRegistered = false

    fun register(context: Context) {
        if (!isRegistered) {
            val filter = IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED)
            ContextCompat.registerReceiver(
                context.applicationContext,
                btStateReceiver,
                filter,
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            isRegistered = true
        }
    }

    fun unregister(context: Context) {
        if (isRegistered) {
            context.applicationContext.unregisterReceiver(btStateReceiver)
            isRegistered = false
        }
    }
}
