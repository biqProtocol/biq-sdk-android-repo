package biq.sdk.android.networking.repositories

import biq.sdk.android.networking.RetrofitInstance
import biq.sdk.android.networking.models.PresenceProofRequestDto
import biq.sdk.android.networking.services.PresenceProofService

internal object PresenceProofServiceRepository {

    private val retService: PresenceProofService by lazy {
        RetrofitInstance
            .authInstance
            .create(PresenceProofService::class.java)
    }

    suspend fun getNonce() = retService.getNonce()

    suspend fun validateSignature(model: PresenceProofRequestDto) =
        retService.validateSignature(listOf(model))

}