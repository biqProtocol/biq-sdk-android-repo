package biq.sdk.android.models

enum class BiqNetworkState(id: Int) {
    UNKNOWN(0),
    NETWORK_LOST(1),
    NETWORK_AVAILABLE(2)
}