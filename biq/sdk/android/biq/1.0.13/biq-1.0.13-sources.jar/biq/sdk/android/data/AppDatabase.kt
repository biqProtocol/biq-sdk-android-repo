package biq.sdk.android.data

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import biq.sdk.android.data.dao.EventAreaDao
import biq.sdk.android.data.dao.EventDao
import biq.sdk.android.data.dao.EventLocationDao
import biq.sdk.android.data.entities.EventAreaEntity
import biq.sdk.android.data.entities.EventEntity
import biq.sdk.android.data.entities.EventLocationEntity

@Database(
    entities = [
        EventEntity::class,
        EventLocationEntity::class,
        EventAreaEntity::class
    ],
    version = 1
)
@TypeConverters(Converters::class)
internal abstract class AppDatabase : RoomDatabase() {
    abstract val eventDao: EventDao
    abstract val eventLocationDao: EventLocationDao
    abstract val eventAreaDao: EventAreaDao
}