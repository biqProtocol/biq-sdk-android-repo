package biq.sdk.android.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import biq.sdk.android.data.entities.EventEntity
import biq.sdk.android.data.entities.relations.EventWithLocations
import biq.sdk.android.data.entities.relations.EventWithLocationsAndAreas
import biq.sdk.android.data.entities.relations.LocationWithAreas

@Dao
internal interface EventDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(event: List<EventEntity>)

    @Transaction
    @Query("SELECT * FROM eventEntity")
    suspend fun getAllEventsWithLocations(): List<EventWithLocations>

    @Transaction
    @Query("SELECT * FROM eventLocationEntity WHERE eventId = :eventId")
    suspend fun getLocationsWithAreasByEvent(eventId: String): List<LocationWithAreas>

    @Transaction
    suspend fun getEventsWithLocationsAndAreas(): List<EventWithLocationsAndAreas> {
        val eventsWithLocations = getAllEventsWithLocations()
        return eventsWithLocations.map { ev ->
            val locWithAreas = ev.locations.map { loc ->
                LocationWithAreas(
                    location = loc,
                    areas = getLocationsWithAreasByEvent(ev.event.id)
                        .firstOrNull { it.location.id == loc.id }
                        ?.areas ?: emptyList()
                )
            }

            EventWithLocationsAndAreas(
                event = ev.event,
                locations = locWithAreas
            )
        }
    }

    @Query("DELETE FROM eventEntity")
    suspend fun deleteAll()
}