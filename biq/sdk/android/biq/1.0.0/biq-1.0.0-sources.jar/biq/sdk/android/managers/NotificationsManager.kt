package biq.sdk.android.managers

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.TaskStackBuilder
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import biq.sdk.android.R
import biq.sdk.android.providers.ContextProvider

// TODO create builder to configure the notification
internal object NotificationsManager {

    private const val BIQ_SCANNING_CHANNEL_ID = "biq_scanning_channel"
    const val BIQ_SCANNING_NOTIFICATION_ID = 24680
    private const val BIQ_ALERTS_CHANNEL_ID = "biq_alerts_channel"
    private const val BIQ_NEARBY_NOTIFICATION_ID = 13579

    private var targetActivityClass: Class<out Activity>? = null

    fun configure(targetActivity: Class<out Activity>) {
        targetActivityClass = targetActivity
    }

    fun getScanningForegroundNotification(): Notification {
        val builder = NotificationCompat.Builder(ContextProvider.get(), BIQ_SCANNING_CHANNEL_ID)
            .setContentTitle("Biq SDK")
            .setSmallIcon(R.drawable.ic_launcher_background)
            .setContentText("Scanning for Beacons")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setSound(null)
            .setVibrate(null)
            .setAutoCancel(false)

        targetActivityClass?.let { activityClass ->
            val intent = Intent(ContextProvider.get(), activityClass)

            val pendingIntent = PendingIntent.getActivity(
                ContextProvider.get(),
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT + PendingIntent.FLAG_IMMUTABLE
            )
            builder.setContentIntent(pendingIntent);
        }

        val channel = NotificationChannel(
            BIQ_SCANNING_CHANNEL_ID,
            "My Notification Name",
            NotificationManager.IMPORTANCE_LOW
        )
        channel.description = "Notification related to ongoing beacon scanning"
        channel.setSound(null, null)
        channel.enableVibration(false)

        val notificationManager = ContextProvider.get().getSystemService(
            Context.NOTIFICATION_SERVICE
        ) as NotificationManager
        notificationManager.createNotificationChannel(channel)
        builder.setChannelId(channel.id)

        val notification = builder.build()
        return notification
    }

    fun cancelScanningNotification() {
        NotificationManagerCompat.from(ContextProvider.get()).cancel(BIQ_SCANNING_NOTIFICATION_ID)
    }

    fun sendNearbyNotification() {
        val builder =
            NotificationCompat.Builder(ContextProvider.get(), BIQ_ALERTS_CHANNEL_ID)
                .setContentTitle("Biq SDK")
                .setContentText("A beacon is nearby.")
                .setSmallIcon(R.drawable.ic_launcher_background)

        targetActivityClass?.let { activityClass ->
            val intent = Intent(ContextProvider.get(), activityClass)
            val stackBuilder = TaskStackBuilder.create(ContextProvider.get())
            stackBuilder.addNextIntent(intent)

            val resultPendingIntent = stackBuilder.getPendingIntent(
                0,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            builder.setContentIntent(resultPendingIntent)
        }

        val channel = NotificationChannel(
            BIQ_ALERTS_CHANNEL_ID,
            "My Notification Name",
            NotificationManager.IMPORTANCE_DEFAULT
        )
        channel.description = "My Notification Channel Description"

        val notificationManager = ContextProvider.get().getSystemService(
            Context.NOTIFICATION_SERVICE
        ) as NotificationManager
        notificationManager.createNotificationChannel(channel);
        builder.setChannelId(channel.id);
        notificationManager.notify(BIQ_NEARBY_NOTIFICATION_ID, builder.build())
    }

    fun cancelNearbyNotification() {
        NotificationManagerCompat.from(ContextProvider.get()).cancel(BIQ_NEARBY_NOTIFICATION_ID)
    }
}