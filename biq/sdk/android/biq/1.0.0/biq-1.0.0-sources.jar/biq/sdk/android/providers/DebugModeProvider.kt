package biq.sdk.android.providers

import biq.sdk.android.BuildConfig
import biq.sdk.android.managers.preferences.PrefsManager
import kotlinx.coroutines.launch

internal object DebugModeProvider {
    private var isDebugModeEnabled: Boolean = false

    fun init(isDebugModeEnabled: Boolean) {
        this.isDebugModeEnabled = isDebugModeEnabled

        CoroutineScopeProvider.get().launch {
            PrefsManager.saveDebugModePreference(isDebugModeEnabled)
        }
    }

    val isDebugOn: Boolean
        get() = this.isDebugModeEnabled && BuildConfig.DEBUG

    val isDebugOff: Boolean
        get() = !isDebugOn
}
