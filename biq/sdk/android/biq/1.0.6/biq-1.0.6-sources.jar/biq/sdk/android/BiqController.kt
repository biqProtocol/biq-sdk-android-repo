package biq.sdk.android

import android.app.Activity
import android.content.Context
import biq.sdk.android.helpers.ConnectionState
import biq.sdk.android.helpers.extensions.isApiKeyNotValid
import biq.sdk.android.helpers.extensions.isRefreshTokenNotValid
import biq.sdk.android.helpers.extensions.logErrorMessage
import biq.sdk.android.managers.NetworkConnectivityManager
import biq.sdk.android.managers.NotificationsManager
import biq.sdk.android.managers.PermissionsManager
import biq.sdk.android.managers.PermissionsManager.PERMISSION_RECEIVE_BOOT_COMPLETED
import biq.sdk.android.managers.beacon.BeaconScannerManager
import biq.sdk.android.managers.preferences.DebugPrefsManager
import biq.sdk.android.managers.preferences.PrefsManager
import biq.sdk.android.models.BiqPresenceState
import biq.sdk.android.models.BiqScanningState
import biq.sdk.android.networking.models.PresenceProofResponseDto
import biq.sdk.android.providers.ConnectionStateProvider
import biq.sdk.android.providers.ContextProvider
import biq.sdk.android.providers.CoroutineScopeProvider
import biq.sdk.android.providers.DatabaseProvider
import biq.sdk.android.providers.DebugModeProvider
import biq.sdk.android.providers.UserSessionProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class BiqController private constructor() {

    interface BiqStateListener {
        fun onSdkStateChanged(newState: BiqPresenceState)
        fun onScanningStateChanged(newState: BiqScanningState)
        fun onValidationRecordsChanged(newRecords: List<PresenceProofResponseDto>)
    }

    private val beaconScannerManager = BeaconScannerManager()
    private var presenceStateListener: BiqStateListener? = null

    companion object {
        const val TAG = "BiqController"

        @Volatile
        private var INSTANCE: BiqController? = null

        fun getInstance(): BiqController {
            return INSTANCE
                ?: throw IllegalStateException("BiqController is not initialized.")
        }
    }

    class Builder(private val context: Context) {
        fun build(): BiqController {
            synchronized(this) {
                if (INSTANCE == null) {
                    ContextProvider.init(context)
                    DatabaseProvider.init()
                    CoroutineScopeProvider.init()
                    INSTANCE = BiqController()
                }
                return INSTANCE!!
            }
        }
    }

    /***
     * Load the current user session.
     */
    fun init(apiKey: String, refreshToken: String): Boolean {
        if(apiKey.isApiKeyNotValid() || refreshToken.isRefreshTokenNotValid()) {
//            throw IllegalArgumentException("Invalid API key or refresh token")
            return false
        }

        CoroutineScopeProvider.get().launch {
            UserSessionProvider.init(
                apiKey = apiKey,
                refreshToken = refreshToken
            )
        }

        return true
    }

    /***
     * Clear the current session.
     */
    fun logOut() = CoroutineScopeProvider.get().launch {
        UserSessionProvider.logout()
        stopPresence()
    }

    /***
     * This activity will be used as entry point when the notification is clicked.
     */
    fun setNotificationEntryPoint(targetActivity: Class<out Activity>) = apply {
        NotificationsManager.configure(targetActivity)
    }

    /***
     * Initialize notification data. Host app can define title and message for scanning and proximity notifications.
     */
    fun initNotificationData(
        iconResId: Int? = null,
        scanningNotificationTitle: String? = null,
        scanningNotificationMessage: String? = null,
        proximityNotificationTitle: String? = null,
        proximityNotificationMessage: String? = null
    ) = apply {
        NotificationsManager.initNotificationData(
            iconResId = iconResId,
            scanningNotificationTitle = scanningNotificationTitle,
            scanningNotificationMessage = scanningNotificationMessage,
            proximityNotificationTitle = proximityNotificationTitle,
            proximityNotificationMessage = proximityNotificationMessage
        )
    }

    fun setBootAutoScan(
        isStartAfterBoot: Boolean,
    ) = apply {
        if (!PermissionsManager.isBootPermissionDeclared()) {
            throw IllegalStateException("$PERMISSION_RECEIVE_BOOT_COMPLETED permission is not declared in manifest")
        }

        CoroutineScopeProvider.get().launch {
            PrefsManager.saveStartAfterBootPreference(isStartAfterBoot)
        }
    }

    /***
     * Start monitoring and ranging beacons, if not already started.
     */
    fun startPresence() {
        beaconScannerManager.startScanning()
    }

    /***
     * Stop any ongoing process related with presence detection.
     * It includes:
     * - beacon ranging and monitoring;
     * - bluetooth scanning and connection;
     * - biq coroutine provider that controls the multithreading work;
     * - cancel pinned scanning notification;
     * - unregister network connectivity manager.
     */
    fun stopPresence() {
        beaconScannerManager.stopScanning()
    }

    /***
     * Check if all required permissions are granted.
     */
    fun areAllPermissionsGranted() = PermissionsManager.getMissingPermission() == null

    /***
     * Get first missing permission encountered.
     */
    fun getMissingPermission() = PermissionsManager.getMissingPermission()

    /***
     * Get current scanning state.
     */
    fun getScanningState() = ConnectionStateProvider.scanningState

    /***
     * Get general SDK state.
     */
    fun getSdkState() = ConnectionStateProvider.state

    fun setPresenceStateListener(stateListener: BiqStateListener?) {
        this.presenceStateListener = stateListener
    }

    internal fun notifyStateChange(newState: BiqPresenceState) {
        this.presenceStateListener?.onSdkStateChanged(newState)
    }

    internal fun notifyScanningChange(newState: BiqScanningState) {
        this.presenceStateListener?.onScanningStateChanged(newState)
    }

    internal fun notifyValidationRecordsChange(newRecords: List<PresenceProofResponseDto>) {
        this.presenceStateListener?.onValidationRecordsChanged(newRecords)
    }

    suspend fun getValidationRecords() = withContext(Dispatchers.IO) {
        DatabaseProvider.getEventRepository().getAll()
    }

    fun setDebugMode(isDebugModeEnabled: Boolean) = apply {
        DebugModeProvider.init(isDebugModeEnabled)
    }

    /***
     * Get validation records from debug prefs.
     */
    suspend fun loadDebugValidationRecords(): String? {
        if (DebugModeProvider.isDebugOff) {
            "[BIQ] Activate debug mode by calling setDebugMode() with true.".logErrorMessage(
                tag = TAG,
                isForced = true
            )
            return null
        }

        return DebugPrefsManager.getValidationsRecords()
    }

    /***
     * Remove validation records from debug prefs.
     */
    fun removeDebugValidationRecords() {
        if (DebugModeProvider.isDebugOff) {
            "[BIQ] Activate debug mode by calling setDebugMode() with true.".logErrorMessage(
                tag = TAG,
                isForced = true
            )
            return
        }

        CoroutineScopeProvider.get().launch {
            DebugPrefsManager.removeValidationsRecords()
        }
    }
}