package biq.sdk.android.managers.beacon

import biq.sdk.android.BiqController
import biq.sdk.android.helpers.extensions.logErrorMessage
import biq.sdk.android.managers.NetworkConnectivityManager
import biq.sdk.android.managers.bluetooth.BluetoothCommunicationManager.BEACON_UUID
import biq.sdk.android.providers.ContextProvider
import com.davidgyoungtech.beaconparsers.IBeaconParser
import org.altbeacon.beacon.BeaconManager
import org.altbeacon.beacon.BeaconRegion
import org.altbeacon.beacon.MonitorNotifier

internal class BeaconUtils {

    private val context get() = ContextProvider.get()
    private val beaconManager get() = BeaconManager.getInstanceForApplication(context)

    @Volatile
    var isInsideRegion = false
        private set

    val iBeaconRegion = BeaconRegion(
        "everyIBeaconRegion",
        IBeaconParser(),
        BEACON_UUID.toString(),
        null,
        null
    )

    fun startRangingBeacons() {
        if(!NetworkConnectivityManager.isConnected()) {
            "[BIQ][BU] No internet connection to start ranging.".logErrorMessage()
            return
        }

        if(!BiqController.getInstance().isBluetoothEnabled()) {
            "[BIQ][BU] Bluetooth not available to start ranging.".logErrorMessage()
            return
        }

        if(!BiqController.getInstance().isLocationEnabled()) {
            "[BIQ][BU] Location services not available to start ranging.".logErrorMessage()
            return
        }

        if (!beaconManager.rangedRegions.contains(iBeaconRegion)) {
            beaconManager.startRangingBeacons(iBeaconRegion)
        }
    }

    fun stopRangingBeacons() {
        if (beaconManager.rangedRegions.contains(iBeaconRegion)) {
            beaconManager.stopRangingBeacons(iBeaconRegion)
        }
    }

    fun startMonitoringBeacon() {
        if (!beaconManager.monitoredRegions.contains(iBeaconRegion)) {
            isInsideRegion = false
            beaconManager.startMonitoring(iBeaconRegion)
        }
    }

    fun stopMonitoringBeacon() {
        if (beaconManager.monitoredRegions.contains(iBeaconRegion)) {
            beaconManager.stopMonitoring(iBeaconRegion)
            isInsideRegion = false
        }
    }

    fun onMonitorNotifier(state: Int) {
        isInsideRegion = when (state == MonitorNotifier.OUTSIDE) {
            true -> false
            else -> true
        }
    }
}
