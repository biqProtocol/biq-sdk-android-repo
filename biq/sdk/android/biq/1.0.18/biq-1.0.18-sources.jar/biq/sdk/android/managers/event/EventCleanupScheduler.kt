package biq.sdk.android.managers.event

import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import biq.sdk.android.BuildConfig
import biq.sdk.android.helpers.extensions.logErrorMessage
import biq.sdk.android.providers.ContextProvider
import biq.sdk.android.workers.EventCleanupWorker
import java.util.concurrent.TimeUnit

internal object EventCleanupScheduler {

    internal val CLEANUP_DELAY_MINUTES by lazy {
        when (BuildConfig.DEBUG) {
            true -> 5L
            false -> 30L
        }
    }

    private const val WORK_NAME_PREFIX = "biq_event_cleanup_"
    private const val WORK_TAG = "biq_event_cleanup"

    fun scheduleCleanup(eventId: String) {
        val request = OneTimeWorkRequestBuilder<EventCleanupWorker>()
            .setInitialDelay(CLEANUP_DELAY_MINUTES, TimeUnit.MINUTES)
            .setInputData(workDataOf(EventCleanupWorker.KEY_EVENT_ID to eventId))
            .addTag(WORK_TAG)
            .build()

        WorkManager.getInstance(ContextProvider.get()).enqueueUniqueWork(
            "$WORK_NAME_PREFIX$eventId",
            ExistingWorkPolicy.REPLACE,
            request
        )

        "[BIQ][ECS] Event with id $eventId scheduled successfully for deletion.".logErrorMessage()
    }
}
