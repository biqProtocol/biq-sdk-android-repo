package biq.sdk.android.data.repositories.event

import biq.sdk.android.data.dao.EventDao
import biq.sdk.android.data.entities.toDto
import biq.sdk.android.networking.models.PresenceProofResponseDto
import biq.sdk.android.networking.models.toEntity


internal class EventDataRepositoryLocal(private val eventDao: EventDao) : EventDataRepository {
    override suspend fun insert(dto: PresenceProofResponseDto) = eventDao.insert(dto.toEntity())

    override suspend fun insertAll(dtoList: List<PresenceProofResponseDto>) =
        eventDao.insertAll(dtoList.map { it.toEntity() })

    override suspend fun getAll() = eventDao.getAll().map { it.toDto() }

    override suspend fun deleteAll() = eventDao.deleteAll()
}