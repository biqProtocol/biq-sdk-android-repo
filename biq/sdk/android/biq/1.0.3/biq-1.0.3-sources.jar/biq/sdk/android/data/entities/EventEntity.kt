package biq.sdk.android.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import biq.sdk.android.networking.models.PresenceProofResponseDto

@Entity(tableName = "eventEntity")
internal data class EventEntity(
    @PrimaryKey
    val id: String,
    val type: String,
    val name: String,
    val description: String,
    val image: String,
    val organizer: String?,
    val url: String?,
    val startTime: Long?,
    val endTime: Long?,
    val isPublic: Boolean?,
    val isGated: Boolean?,
    val tags: List<String>?,
    val owners: List<String>?
)

// locations?

internal fun EventEntity.toDto() = PresenceProofResponseDto(
    id = id,
    type = type,
    name = name,
    description = description,
    image = image,
    organizer = organizer,
    url = url,
    startTime = startTime,
    endTime = endTime,
    isPublic = isPublic,
    isGated = isGated,
    tags = tags,
    owners = owners
)