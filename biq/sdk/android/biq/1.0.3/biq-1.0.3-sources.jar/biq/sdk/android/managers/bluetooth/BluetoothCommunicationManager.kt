package biq.sdk.android.managers.bluetooth

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import androidx.annotation.RequiresPermission
import biq.sdk.android.BuildConfig
import biq.sdk.android.helpers.extensions.logDebugMessage
import biq.sdk.android.helpers.extensions.logErrorMessage
import biq.sdk.android.helpers.extensions.logInfoMessage
import biq.sdk.android.helpers.extensions.logWarningMessage
import biq.sdk.android.helpers.utils.Base58
import biq.sdk.android.managers.beacon.BeaconScannerManager
import biq.sdk.android.managers.preferences.DebugPrefsManager
import biq.sdk.android.models.BiqPresenceState
import biq.sdk.android.networking.models.PresenceProofRequestDto
import biq.sdk.android.networking.repositories.PresenceProofServiceRepository
import biq.sdk.android.providers.ConnectionStateProvider
import biq.sdk.android.providers.ContextProvider
import biq.sdk.android.providers.DatabaseProvider
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.time.LocalDateTime
import java.util.UUID
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi

// TODO take a second look over deprecations
@Suppress("Deprecation")
internal object BluetoothCommunicationManager {
    private const val TAG = "BluetoothCommunicationManager"

    /***
     *  standard Bluetooth SIG‑assigned UUID for the Client Characteristic Configuration
     *  Descriptor (CCCD), which is used to enable or disable notifications/indications
     *  on a characteristic. In the BLE specification, descriptors live under the “0x2900”
     *  series, and 0x2902 specifically is the CCCD.
     */
    private val CLIENT_CHARACTERISTIC_CONFIG_UUID =
        UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    val BEACON_UUID: UUID = UUID.fromString("2c1cb000-fd03-4b10-a8f9-325096b39f47")
    private val SERVICE_UUID: UUID = UUID.fromString("2c1cb000-fd03-4b10-a8f9-325096b39f47")
    private val INFO_UUID: UUID = UUID.fromString("2c1cb001-fd03-4b10-a8f9-325096b39f47")
    private val TX_UUID: UUID = UUID.fromString("2c1cb003-fd03-4b10-a8f9-325096b39f47")
    private val RX_UUID: UUID = UUID.fromString("2c1cb002-fd03-4b10-a8f9-325096b39f47")

    data class PeripheralSignature(
        val uuid: String,
        val major: Int,
        val minor: Int,
        val publicKey: String,
        val signature: String
    )

    private val beaconHandlerMutex = Mutex()

    @OptIn(ExperimentalEncodingApi::class)
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    suspend fun handleDetectedBeacon(
        device: BluetoothDevice,
    ) = beaconHandlerMutex.withLock {
//        val lastUsage = PrefsManager.getBeaconDate(BEACON_UUID.toString())
//        val isReady = lastUsage == null || lastUsage.isBefore(
//            LocalDateTime.now().minusSeconds(30)
//        )//.minusMinutes(2))
//
//        if (!isReady) {
//            "[BIQ][BCM] Not ready to BLE connection, need to wait longer.".logWarningMessage()
//            return@withLock false
//        }
//
//        PrefsManager.saveBeaconDate(BEACON_UUID.toString())

        BluetoothScannerManager.foundBeaconsToConnect.forEach { entry ->
            val restrictionMinutes = when (BuildConfig.DEBUG) {
                true -> 1L
                else -> BeaconScannerManager.Companion.VALIDATION_RESTRICTION_MINUTES
            }

            val isAvailable = entry.value.lastValidationAt == null ||
                    entry.value.lastValidationAt?.isBefore(
                        LocalDateTime.now().minusMinutes(restrictionMinutes)
                    ) == true

            if (!isAvailable) {
                ("[BIQ][BCM] Not available to start signing&validation process " +
                        "for uuid=${entry.value.beacon.id1}, " +
                        "major=${entry.value.beacon.id2}, " +
                        "minor=${entry.value.beacon.id3}").logWarningMessage()
                return@forEach
            }

            val beacon = entry.value.beacon
            ("[BIQ][BCM] Nonce signing&validation process started at: ${LocalDateTime.now()}, " +
                    "for uuid=${beacon.id1}, " +
                    "major=${beacon.id2}, " +
                    "minor=${beacon.id3}").logInfoMessage()

            DebugPrefsManager.saveValidationStateTimestamp(true)
            ConnectionStateProvider.updateState(BiqPresenceState.VALIDATION_IN_PROGRESS)

            val nonce = try {
                val base64Nonce = getNonce()
                Base64.decode(base64Nonce)
            } catch (e: Exception) {
                "[BIQ][BCM] Failed to get nonce: ${e.message}".apply {
                    logErrorMessage()
                    DebugPrefsManager.saveValidationLog(this)
                }
                ConnectionStateProvider.updateState(BiqPresenceState.SCANNING_IN_PROGRESS)
                return@withLock false
            }

            try {
                val signature = retryBLE {
                    device.signNonce(
                        nonce = nonce,
                        beaconInfo = entry.value
                    )
                }

                // TODO: Handle empty array, when validation is not happening
                val signatureResult = sendSignature(signature)

                DatabaseProvider.getEventRepository().deleteAll()
                DatabaseProvider.getEventRepository().insertAll(signatureResult)

                BluetoothScannerManager.updateValidatedBeacon(entry.key)
                DebugPrefsManager.saveValidationTimestamp(signatureResult.joinToString { it.id })
                DebugPrefsManager.saveValidationStateTimestamp(isStarted = false, isSuccess = true)
                "[BIQ][BCM] BLE validation success!".logErrorMessage()
            } catch (e: Exception) {
                "[BIQ][BCM] BLE validation failed: ${e.message}".logErrorMessage()
                DebugPrefsManager.saveValidationStateTimestamp(isStarted = false, isSuccess = false)
            } finally {
                ("[BIQ][BCM] Nonce signing&validation process finished at: ${LocalDateTime.now()}, " +
                        "for uuid=${beacon.id1}, " +
                        "major=${beacon.id2}, " +
                        "minor=${beacon.id3}").logInfoMessage()
                ConnectionStateProvider.updateState(BiqPresenceState.SCANNING_IN_PROGRESS)
            }
        }
    }

    @SuppressLint("MissingPermission")
    private suspend fun BluetoothDevice.signNonce(
        nonce: ByteArray,
        beaconInfo: BeaconScannerManager.BeaconInfo
    ): PeripheralSignature = withContext(Dispatchers.IO) {
        val callback = GattCoroutineCallback()
        val gatt = connectGatt(ContextProvider.get(), false, callback)

        try {
            // 1. Wait for connect
            callback.awaitConnection()

            // 2. Request MTU
            callback.prepareMtu()
            gatt.requestMtu(517)
            callback.awaitMtu()

            // 3. Discover services
            callback.prepareServices()
            gatt.discoverServices()
            callback.awaitServices()

            val service = gatt.getService(SERVICE_UUID)
                ?: error("Service missing")
            val infoChar = service.getCharacteristic(INFO_UUID)
                ?: error("Info char missing")
            val rxChar = service.getCharacteristic(RX_UUID)
                ?: error("RX char missing")
            val txChar = service.getCharacteristic(TX_UUID)
                ?: error("TX char missing")

            // 4. Read public key
            val readDef = callback.prepareRead(infoChar.uuid)
            gatt.readCharacteristic(infoChar)
            val pkBytes = readDef.await()
            val pkBs58 = Base58.encode(pkBytes)
            beaconInfo.publicKey = pkBs58

            // 5. Enable notifications
            val cccd = rxChar.getDescriptor(CLIENT_CHARACTERISTIC_CONFIG_UUID)
                ?: error("CCCD not found")
            val descDef = callback.prepareDescriptor(cccd)
            gatt.setCharacteristicNotification(rxChar, true)
            cccd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            gatt.writeDescriptor(cccd)
            try {
                descDef.await()
            } catch (e: Exception) {
                error("CCCD write failed: ${e.message}")
            }

            // 6. Prepare notification listener BEFORE writing the nonce
            val notifyDef = callback.prepareNotify(rxChar)

            // 7. Write nonce
            val writeDef = callback.prepareWrite(txChar.uuid)
            txChar.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            txChar.value = nonce
            gatt.writeCharacteristic(txChar)
            writeDef.await()

            // 8. Await signature notification
            val sigBytes = withTimeoutOrNull(3000L) {
                notifyDef.await()
            } ?: error("Timed out waiting for signature notification")
            val sigBs58 = Base58.encode(sigBytes)

            // 9. Build result
            PeripheralSignature(
                uuid = beaconInfo.beacon.id1.toString(),
                major = beaconInfo.beacon.id2.toInt(),
                minor = beaconInfo.beacon.id3.toInt(),
                publicKey = beaconInfo.publicKey,
                signature = sigBs58
            )
        } finally {
            try {
                gatt.disconnect()
            } catch (_: Exception) {
            }

            gatt.close()
        }
    }

    private class GattCoroutineCallback : BluetoothGattCallback() {
        private val connectDeferred = CompletableDeferred<BluetoothGatt>()
        private val mtuDeferred = CompletableDeferred<Int>()
        private val svcDeferred = CompletableDeferred<Unit>()
        private val readMap = mutableMapOf<UUID, CompletableDeferred<ByteArray>>()
        private val writeMap = mutableMapOf<UUID, CompletableDeferred<Unit>>()
        private val descriptorMap =
            mutableMapOf<BluetoothGattDescriptor, CompletableDeferred<Unit>>()
        private val notifyMap = mutableMapOf<UUID, CompletableDeferred<ByteArray>>()

        @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
                connectDeferred.complete(gatt)
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                connectDeferred.completeExceptionally(
                    IllegalStateException("Disconnected")
                )
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                mtuDeferred.complete(mtu)
            } else {
                mtuDeferred.completeExceptionally(
                    RuntimeException("MTU failed $status")
                )
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                svcDeferred.complete(Unit)
            } else {
                svcDeferred.completeExceptionally(
                    RuntimeException("Discover failed $status")
                )
            }
        }

        @Deprecated("Deprecated in Java")
        override fun onCharacteristicRead(
            gatt: BluetoothGatt,
            char: BluetoothGattCharacteristic, status: Int
        ) {
            readMap.remove(char.uuid)?.also { deferred ->
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    deferred.complete(char.value)
                } else {
                    deferred.completeExceptionally(
                        RuntimeException("Read failed $status")
                    )
                }
            }
        }

        override fun onDescriptorWrite(
            gatt: BluetoothGatt,
            descriptor: BluetoothGattDescriptor,
            status: Int
        ) {
            descriptorMap.remove(descriptor)?.also { deferred ->
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    deferred.complete(Unit)
                } else {
                    deferred.completeExceptionally(
                        RuntimeException("Descriptor write failed $status")
                    )
                }
            }
        }

        override fun onCharacteristicWrite(
            gatt: BluetoothGatt,
            char: BluetoothGattCharacteristic,
            status: Int
        ) {
            writeMap.remove(char.uuid)?.also { deferred ->
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    deferred.complete(Unit)
                } else {
                    deferred.completeExceptionally(
                        RuntimeException("Write failed $status")
                    )
                }
            }
        }

        @Deprecated("Deprecated in Java")
        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            "[BIQ][BCM] GattCallback: Notification received on: ${characteristic.uuid}".logDebugMessage()
            notifyMap.remove(characteristic.uuid)?.complete(characteristic.value)
                ?: "[BIQ][BCM] GattCallback: No listener for UUID: ${characteristic.uuid}".logWarningMessage()
        }

        fun prepareMtu() = mtuDeferred
        suspend fun awaitMtu() = mtuDeferred.await()
        fun prepareServices() = svcDeferred
        suspend fun awaitServices() = svcDeferred.await()
        suspend fun awaitConnection() = connectDeferred.await()

        fun prepareRead(uuid: UUID): CompletableDeferred<ByteArray> {
            val deferred = CompletableDeferred<ByteArray>()
            readMap[uuid] = deferred
            return deferred
        }

        fun prepareWrite(u: UUID): CompletableDeferred<Unit> {
            val deferred = CompletableDeferred<Unit>()
            writeMap[u] = deferred
            return deferred
        }

        fun prepareDescriptor(desc: BluetoothGattDescriptor): CompletableDeferred<Unit> {
            val deferred = CompletableDeferred<Unit>()
            descriptorMap[desc] = deferred
            return deferred
        }

        fun prepareNotify(char: BluetoothGattCharacteristic): CompletableDeferred<ByteArray> {
            val deferred = CompletableDeferred<ByteArray>()
            notifyMap[char.uuid] = deferred
            return deferred
        }
    }

    private suspend fun getNonce() =
        PresenceProofServiceRepository.getNonce()

    private suspend fun sendSignature(signature: PeripheralSignature) =
        PresenceProofServiceRepository.validateSignature(
            PresenceProofRequestDto(
                uuid = signature.uuid,
                major = signature.major,
                minor = signature.minor,
                publicKey = signature.publicKey,
                signature = signature.signature
            )
        )
}

suspend fun <T> retryBLE(
    times: Int = 3,
    delayMillis: Long = 750,
    block: suspend () -> T
): T {
    var lastError: Throwable? = null
    repeat(times) {
        try {
            return block()
        } catch (e: Throwable) {
            lastError = e
            delay(delayMillis)
        }
    }
    throw lastError ?: IllegalStateException("BLE operation failed")
}
