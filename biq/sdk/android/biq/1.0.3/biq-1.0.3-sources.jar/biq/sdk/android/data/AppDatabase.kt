package biq.sdk.android.data

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import biq.sdk.android.data.dao.EventDao
import biq.sdk.android.data.entities.EventEntity

@Database(
    entities = [
        EventEntity::class
    ],
    version = 1
)
@TypeConverters(Converters::class)
internal abstract class AppDatabase : RoomDatabase() {
    abstract val eventDao: EventDao
}