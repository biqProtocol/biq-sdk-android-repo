package biq.sdk.android.networking.models

import biq.sdk.android.data.entities.EventEntity

internal data class PresenceProofRequestDto(
    val uuid: String,
    val major: Int,
    val minor: Int,
    val publicKey: String,
    val signature: String
)

data class PresenceProofResponseDto(
    val id: String,
    val type: String,
    val name: String,
    val description: String,
    val image: String,
    val organizer: String?,
    val url: String?,
    val startTime: Long?,
    val endTime: Long?,
    val isPublic: Boolean?,
    val isGated: Boolean?,
    val tags: List<String>?,
    val owners: List<String>?
)

internal fun PresenceProofResponseDto.toEntity() = EventEntity(
    id = id,
    type = type,
    name = name,
    description = description,
    image = image,
    organizer = organizer,
    url = url,
    startTime = startTime,
    endTime = endTime,
    isPublic = isPublic,
    isGated = isGated,
    tags = tags,
    owners = owners
)