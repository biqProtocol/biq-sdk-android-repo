package biq.sdk.android.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import biq.sdk.android.data.entities.EventEntity

@Dao
internal interface EventDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(event: EventEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(event: List<EventEntity>)

    @Query("SELECT * FROM eventEntity")
    fun getAll(): List<EventEntity>

    @Query("DELETE FROM eventEntity")
    fun deleteAll()

}