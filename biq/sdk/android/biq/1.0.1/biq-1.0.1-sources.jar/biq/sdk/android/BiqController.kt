package biq.sdk.android

import android.app.Activity
import android.content.Context
import biq.sdk.android.helpers.ConnectionState
import biq.sdk.android.helpers.extensions.logErrorMessage
import biq.sdk.android.managers.beacon.BeaconScannerManager
import biq.sdk.android.managers.NotificationsManager
import biq.sdk.android.managers.PermissionsManager
import biq.sdk.android.managers.PermissionsManager.PERMISSION_RECEIVE_BOOT_COMPLETED
import biq.sdk.android.managers.preferences.DebugPrefsManager
import biq.sdk.android.managers.preferences.PrefsManager
import biq.sdk.android.providers.ContextProvider
import biq.sdk.android.providers.CoroutineScopeProvider
import biq.sdk.android.providers.DebugModeProvider
import biq.sdk.android.providers.UserSessionProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class BiqController private constructor() {

    private val beaconScannerManager = BeaconScannerManager()

    companion object {
        const val TAG = "BiqController"

        @Volatile
        private var INSTANCE: BiqController? = null

        fun getInstance(): BiqController {
            return INSTANCE
                ?: throw IllegalStateException("BiqController is not initialized.")
        }
    }

    class Builder(private val context: Context) {
        fun build(): BiqController {
            synchronized(this) {
                if (INSTANCE == null) {
                    ContextProvider.init(context)
                    CoroutineScopeProvider.init()
                    INSTANCE = BiqController()
                }
                return INSTANCE!!
            }
        }
    }

    fun init(apiKey: String, refreshToken: String) = CoroutineScopeProvider.get().launch {
        UserSessionProvider.init(
            apiKey = apiKey,
            refreshToken = refreshToken
        )
    }

    fun setNotificationEntryPoint(targetActivity: Class<out Activity>) = apply {
        NotificationsManager.configure(targetActivity)
    }

    fun setDebugMode(isDebugModeEnabled: Boolean) = apply {
        DebugModeProvider.init(isDebugModeEnabled)
    }

    fun setBootAutoScan(
        isStartAfterBoot: Boolean,
    ) = apply {
        if (!PermissionsManager.isBootPermissionDeclared()) {
            throw IllegalStateException("$PERMISSION_RECEIVE_BOOT_COMPLETED permission is not declared in manifest")
        }

        CoroutineScopeProvider.get().launch {
            PrefsManager.saveStartAfterBootPreference(isStartAfterBoot)
        }
    }

    fun startPresence(onPermissionError: (ConnectionState.MissingPermission) -> Unit) {
        beaconScannerManager.startScanning(onPermissionError)
    }

    fun stopPresence() {
        beaconScannerManager.stopScanning()
    }

    /***
     * Check if all required permissions are granted
     */
    fun checkPermissions(
        onPermissionError: ((ConnectionState.MissingPermission) -> Unit)? = null
    ) = PermissionsManager.allPermissionsGranted()

    /***
     * Set and validate user credential (idToken) and start background fetch of events in user area
     */
    // TODO find out if this is required
    suspend fun setUser(
        userCredential: String?,
        onSuccess: ConnectionState.Success<String>,
        onError: (ConnectionState.Error) -> Unit
    ) = withContext(Dispatchers.IO) {
        //doNetworkCall()

//        if user is valid
//        then UserSessionProvider.init(userCredential)
    }

    suspend fun loadDebugValidationRecords(): String? {
        if (DebugModeProvider.isDebugOff) {
            "[BIQ] Activate debug mode by calling setDebugMode() with true.".logErrorMessage(
                tag = TAG,
                isForced = true
            )
            return null
        }

        return DebugPrefsManager.getValidationsRecords()
    }

    suspend fun removeDebugValidationRecords() {
        if (DebugModeProvider.isDebugOff) {
            "[BIQ] Activate debug mode by calling setDebugMode() with true.".logErrorMessage(
                tag = TAG,
                isForced = true
            )
            return
        }

        DebugPrefsManager.removeValidationsRecords()
    }
}