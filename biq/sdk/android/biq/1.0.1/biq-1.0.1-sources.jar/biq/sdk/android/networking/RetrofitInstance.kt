package biq.sdk.android.networking

import biq.sdk.android.networking.interceptors.ApiKeyInterceptor
import biq.sdk.android.networking.interceptors.SessionAuthInterceptor
import biq.sdk.android.networking.interceptors.TokenAuthenticator
import kotlinx.coroutines.delay
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

internal object RetrofitInstance {

    private const val API_BASE_URL = "https://biq-backend.vercel.app/"

    private val loggingInterceptor =
        HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

    private val sessionAuthInterceptor = SessionAuthInterceptor()
    private val apiKeyInterceptor = ApiKeyInterceptor()
    private val tokenAuthenticator = TokenAuthenticator()

    private val client = OkHttpClient.Builder().apply {
        this.addInterceptor(loggingInterceptor)
            .addInterceptor(apiKeyInterceptor)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(25, TimeUnit.SECONDS)
    }.build()

    val instance: Retrofit = Retrofit.Builder()
        .baseUrl(API_BASE_URL)
        .client(client)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    private val authClient = OkHttpClient.Builder().apply {
        this.addInterceptor(loggingInterceptor)
            .addInterceptor(apiKeyInterceptor)
            .addInterceptor(sessionAuthInterceptor)
            .authenticator(tokenAuthenticator)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(25, TimeUnit.SECONDS)
    }.build()

    val authInstance: Retrofit = Retrofit.Builder()
        .baseUrl(API_BASE_URL)
        .client(authClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
}

internal suspend fun <T> retryWithFallback(
    maxRetries: Int = 3,
    retryDelayMillis: Long = 1000L,
    shouldSkipRetry: (Exception) -> Boolean = { false },
    onError: (Exception) -> Unit = {},
    onFinalFailure: (Exception) -> Unit = {},
    block: suspend () -> T?,
    fallback: suspend () -> T?
): T? {
    var lastError: Exception? = null

    repeat(maxRetries) {
        try {
            return block()
        } catch (e: Exception) {
            if (shouldSkipRetry(e)) throw e

            lastError = e
            onError(e)
            delay(retryDelayMillis)
        }
    }

    lastError?.let { onFinalFailure(it) }
    return fallback()
}


