package biq.sdk.android.managers.bluetooth

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.os.ParcelUuid
import androidx.annotation.RequiresPermission
import biq.sdk.android.helpers.extensions.logDebugMessage
import biq.sdk.android.helpers.extensions.logWarningMessage
import biq.sdk.android.managers.bluetooth.BluetoothCommunicationManager.BEACON_UUID
import biq.sdk.android.managers.beacon.BeaconScannerManager.BeaconInfo
import biq.sdk.android.managers.beacon.BeaconScannerManager.BeaconKey
import biq.sdk.android.providers.CoroutineScopeProvider
import kotlinx.coroutines.launch
import org.altbeacon.beacon.Beacon
import java.time.LocalDateTime

internal object BluetoothScannerManager {

    private val scannerToConnect = BluetoothAdapter.getDefaultAdapter().bluetoothLeScanner

    private val expectedUUID = ParcelUuid.fromString(BEACON_UUID.toString())

    private val settings = ScanSettings.Builder()
        .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
        .build()

    private val filters = listOf(
        ScanFilter.Builder()
            .setServiceUuid(expectedUUID)
            .build()
    )

    private var isScanning = false

    private val _foundBeaconsToConnect = mutableMapOf<BeaconKey, BeaconInfo>()
    val foundBeaconsToConnect: Map<BeaconKey, BeaconInfo> get() = _foundBeaconsToConnect

    fun recordBeaconToConnect(
        key: BeaconKey,
        beacon: Beacon
    ) = _foundBeaconsToConnect.putIfAbsent(key, BeaconInfo(beacon))

    fun updateValidatedBeacon(key: BeaconKey) =
        foundBeaconsToConnect[key]?.lastValidationAt = LocalDateTime.now()

    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    fun startScan() {
        if (!isScanning) {
            scannerToConnect.startScan(filters, settings, scanToConnectCallback)
            isScanning = true
        } else {
            "[BIQ][BSM] Scan already in progress.".logWarningMessage()
        }
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    fun stopScan() {
        if (isScanning) {
            scannerToConnect.stopScan(scanToConnectCallback)
            isScanning = false
        }
    }

    val scanToConnectCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val address = device.address
            val name = device.name ?: "Unknown"
            val uuids = result.scanRecord?.serviceUuids?.joinToString() ?: "None"

            "[BIQ][BSM] 📡 Found device: $name, $address, UUIDs: $uuids".logDebugMessage()

            if (result.scanRecord?.serviceUuids?.contains(expectedUUID) == true) {
                "[BIQ][BSM] 🎯 Target device found, connecting to $address".logDebugMessage()
                CoroutineScopeProvider.get().launch {
                    BluetoothCommunicationManager.handleDetectedBeacon(
                        device = result.device
                    )
                }
            }
        }
    }

}