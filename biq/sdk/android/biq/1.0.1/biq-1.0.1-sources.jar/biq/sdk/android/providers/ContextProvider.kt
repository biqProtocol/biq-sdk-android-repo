package biq.sdk.android.providers

import android.content.Context

internal object ContextProvider {
    private var appContext: Context? = null

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    fun get(): Context {
        return appContext
            ?: throw IllegalStateException("ContextProvider is not initialized. Call init() with application context.")
    }
}
