package biq.sdk.android.managers.beacon

import biq.sdk.android.managers.bluetooth.BluetoothCommunicationManager.BEACON_UUID
import biq.sdk.android.providers.ContextProvider
import com.davidgyoungtech.beaconparsers.IBeaconParser
import org.altbeacon.beacon.BeaconManager
import org.altbeacon.beacon.BeaconRegion

object BeaconUtils {

    private val context get() = ContextProvider.get()
    private val beaconManager get() = BeaconManager.getInstanceForApplication(context)

    val iBeaconRegion = BeaconRegion(
        "everyIBeaconRegion",
        IBeaconParser(),
        BEACON_UUID.toString(),
        null,
        null
    )

    fun startRangingBeacons() {
        if (!beaconManager.rangedRegions.contains(iBeaconRegion)) {
            beaconManager.startRangingBeacons(iBeaconRegion)
        }
    }

    fun stopRangingBeacons() {
        if (beaconManager.rangedRegions.contains(iBeaconRegion)) {
            beaconManager.stopRangingBeacons(iBeaconRegion)
        }
    }

    fun startMonitoringBeacon() {
        if (!beaconManager.monitoredRegions.contains(iBeaconRegion)) {
            beaconManager.startMonitoring(iBeaconRegion)
        }
    }

    fun stopMonitoringBeacon() {
        if (beaconManager.monitoredRegions.contains(iBeaconRegion)) {
            beaconManager.stopMonitoring(iBeaconRegion)
        }
    }
}
