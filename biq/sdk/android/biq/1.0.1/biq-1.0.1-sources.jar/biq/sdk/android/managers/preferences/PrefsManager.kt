package biq.sdk.android.managers.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import biq.sdk.android.providers.ContextProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.time.LocalDateTime

// Create extension to get DataStore instance
private val Context.dataStore by preferencesDataStore(name = "biq_sdk_prefs")

internal object PrefsManager {

    private val context: Context get() = ContextProvider.get()

    private const val BOOT_ACTIVATION_KEY = "isBootStartAvailable"
    private const val DEBUG_MODE_KEY = "isDebugAvailable"

    private suspend fun writeString(key: String, value: String) = withContext(Dispatchers.IO) {
        context.dataStore.edit { prefs ->
            prefs[stringPreferencesKey(key)] = value
        }
    }

    private suspend fun readString(key: String): String? = withContext(Dispatchers.IO) {
        val prefKey = stringPreferencesKey(key)
        val prefs = context.dataStore.data.first()
        prefs[prefKey]
    }

    private suspend fun writeBoolean(key: String, value: Boolean) = withContext(Dispatchers.IO) {
        context.dataStore.edit { prefs ->
            prefs[booleanPreferencesKey(key)] = value
        }
    }

    private suspend fun readBoolean(key: String): Boolean? = withContext(Dispatchers.IO) {
        val prefKey = booleanPreferencesKey(key)
        val prefs = context.dataStore.data.first()
        prefs[prefKey]
    }

    private suspend fun remove(key: String) = withContext(Dispatchers.IO) {
        context.dataStore.edit { prefs ->
            prefs.remove(stringPreferencesKey(key))
        }
    }

    suspend fun saveBeaconDate(beaconId: String) =
        writeString(beaconId, LocalDateTime.now().toString())

    suspend fun getBeaconDate(beaconId: String) =
        readString(beaconId)?.let { LocalDateTime.parse(it) }

    suspend fun saveStartAfterBootPreference(isStartAfterBoot: Boolean) =
        writeBoolean(BOOT_ACTIVATION_KEY, isStartAfterBoot)

    suspend fun getStartAfterBootPreference() =
        readBoolean(BOOT_ACTIVATION_KEY) ?: false

    suspend fun saveDebugModePreference(iseDebugAvailable: Boolean) =
        writeBoolean(DEBUG_MODE_KEY, iseDebugAvailable)

    suspend fun getDebugModePreference() =
        readBoolean(DEBUG_MODE_KEY) ?: false
}