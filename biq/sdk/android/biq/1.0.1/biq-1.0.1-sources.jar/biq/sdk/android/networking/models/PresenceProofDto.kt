package biq.sdk.android.networking.models

data class PresenceProofRequestDto(
    val uuid: String,
    val major: Int,
    val minor: Int,
    val publicKey: String,
    val signature: String
)

data class PresenceProofResponseDto(
    val id: String,
    val type: String,
    val name: String,
    val description: String,
    // TODO add more parameters if needed
)