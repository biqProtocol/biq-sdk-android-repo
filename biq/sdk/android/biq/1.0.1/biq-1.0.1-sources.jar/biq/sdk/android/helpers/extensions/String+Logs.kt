package biq.sdk.android.helpers.extensions

import android.util.Log
import biq.sdk.android.BuildConfig
import biq.sdk.android.providers.DebugModeProvider

internal fun String.logErrorMessage(tag: String = "", isForced: Boolean = false) {
    if (DebugModeProvider.isDebugOn  || isForced) {
        Log.e(tag, this)
    }
}

internal fun String.logDebugMessage(tag: String = "") {
    if (DebugModeProvider.isDebugOn) {
        Log.d(tag, this)
    }
}

internal fun String.logWarningMessage(tag: String = "") {
    if (DebugModeProvider.isDebugOn) {
        Log.w(tag, this)
    }
}

internal fun String.logInfoMessage(tag: String = "") {
    if (DebugModeProvider.isDebugOn) {
        Log.i(tag, this)
    }
}