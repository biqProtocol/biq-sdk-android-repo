package biq.sdk.android.helpers

sealed class ConnectionState<out T> {
    data object Loading : ConnectionState<Nothing>()

    data class Success<T>(val data: T) : ConnectionState<T>()

    data class Error(
        val exception: Throwable? = null,
        val message: String? = null
    ) : ConnectionState<Nothing>()

    data class MissingPermission(
        val permission: String
    ) : ConnectionState<Nothing>()
}