package biq.sdk.android.networking.interceptors

import biq.sdk.android.networking.repositories.AuthenticationServiceRepository
import biq.sdk.android.providers.UserSessionProvider
import kotlinx.coroutines.runBlocking
import okhttp3.Authenticator
import okhttp3.Request
import okhttp3.Response
import okhttp3.Route

internal class TokenAuthenticator() : Authenticator {

    override fun authenticate(route: Route?, response: Response): Request? {
        if (responseCount(response) >= 2) return null

        val newToken = runBlocking {
            try {
                val refreshToken = UserSessionProvider.getRefresh() ?: return@runBlocking null

                val refreshResponse = AuthenticationServiceRepository.refreshToken(refreshToken)
                if (refreshResponse.isSuccessful) {
                    val body = refreshResponse.body()
                    body?.let { response ->
                        UserSessionProvider.set(response.idToken)
                        return@runBlocking response.idToken
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return@runBlocking null
        }

        return newToken?.let {
            response.request.newBuilder()
                .header(
                    name = SessionAuthInterceptor.AUTHORIZATION,
                    value = "${SessionAuthInterceptor.BEARER} $it"
                )
                .build()
        }
    }

    private fun responseCount(response: Response): Int {
        var count = 1
        var res = response.priorResponse
        while (res != null) {
            count++
            res = res.priorResponse
        }
        return count
    }
}
