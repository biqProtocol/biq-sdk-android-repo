package biq.sdk.android.networking.models

data class RefreshAuthRequestDto(
    val refreshToken: String
)

data class RefreshAuthResponseDto(
    val idToken: String
)