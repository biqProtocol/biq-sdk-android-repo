package biq.sdk.android.managers.bluetooth

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.os.ParcelUuid
import androidx.annotation.RequiresPermission
import biq.sdk.android.helpers.extensions.logDebugMessage
import biq.sdk.android.helpers.extensions.logWarningMessage
import biq.sdk.android.managers.bluetooth.BluetoothCommunicationManager.BEACON_UUID
import biq.sdk.android.managers.beacon.BeaconScannerManager.BeaconInfo
import biq.sdk.android.managers.beacon.BeaconScannerManager.BeaconKey
import biq.sdk.android.providers.CoroutineScopeProvider
import kotlinx.coroutines.launch
import org.altbeacon.beacon.Beacon
import java.time.LocalDateTime

internal object BluetoothScannerManager {

    private val scannerToConnect = BluetoothAdapter.getDefaultAdapter().bluetoothLeScanner

    private val expectedUUID = ParcelUuid.fromString(BEACON_UUID.toString())

    private val settings = ScanSettings.Builder()
        .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
        .build()

    private val filters = listOf(
        ScanFilter.Builder()
            .setServiceUuid(expectedUUID)
            .build()
    )

    private var isScanning = false

    private val _foundBeaconsToConnect = mutableMapOf<BeaconKey, BeaconInfo>()
    val foundBeaconsToConnect: Map<BeaconKey, BeaconInfo> get() = _foundBeaconsToConnect

    fun recordBeaconToConnect(
        key: BeaconKey,
        beacon: Beacon
    ) = _foundBeaconsToConnect.putIfAbsent(key, BeaconInfo(beacon))

    fun updateValidatedBeacon(key: BeaconKey) =
        foundBeaconsToConnect[key]?.lastValidationAt = LocalDateTime.now()

    fun resetValidatedBeacons() {
        _foundBeaconsToConnect.clear()
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    fun startScan() {
        if (!isScanning) {
            scannerToConnect.startScan(filters, settings, scanToConnectCallback)
            isScanning = true
        } else {
            "[BIQ][BSM] Scan already in progress.".logWarningMessage()
        }
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    fun stopScan() {
        if (isScanning) {
            scannerToConnect.stopScan(scanToConnectCallback)
            isScanning = false
        }
    }

    val scanToConnectCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val address = device.address
            val name = device.name ?: "Unknown"
            val uuids = result.scanRecord?.serviceUuids?.joinToString() ?: "None"

            "[BIQ][BSM] 📡 Found device: $name, $address, UUIDs: $uuids".logDebugMessage()

            if (result.scanRecord?.serviceUuids?.contains(expectedUUID) == true) {
                val beaconKey = extractBeaconKeyFromScanResult(result)
                
                "[BIQ][BSM] 🎯 Target device found, connecting to $address, beaconKey=$beaconKey".logDebugMessage()
                CoroutineScopeProvider.get().launch {
                    BluetoothCommunicationManager.handleDetectedBeacon(
                        device = result.device,
                        beaconKey = beaconKey
                    )
                }
            }
        }
    }

    /**
     * Finds an available beacon that needs validation.
     *
     * @param beaconKey Optional beacon key to match a specific beacon. If null, finds the first available beacon.
     * @param beaconsBeingValidated Set of beacon keys that are currently being validated (to exclude them).
     * @param restrictionMinutes Minimum time in minutes that must pass before re-validating a beacon.
     * @return A map entry with the beacon key and info, or null if no available beacon is found.
     */
    fun findAvailableBeacon(
        beaconKey: BeaconKey?,
        beaconsBeingValidated: Set<BeaconKey>,
        restrictionMinutes: Long
    ): Map.Entry<BeaconKey, BeaconInfo>? {
        return if (beaconKey != null) {
            // If we have beacon identification from the scan, use it to find the exact beacon
            foundBeaconsToConnect.entries.firstOrNull { entry ->
                entry.key == beaconKey && !beaconsBeingValidated.contains(entry.key)
            }
        } else {
            // Fallback: Find the first available beacon that needs validation and is not being validated
            foundBeaconsToConnect.entries.firstOrNull { entry ->
                val beaconInfo = entry.value
                val isAvailable = beaconInfo.lastValidationAt == null ||
                        beaconInfo.lastValidationAt?.isBefore(
                            LocalDateTime.now().minusMinutes(restrictionMinutes)
                        ) == true
                isAvailable && !beaconsBeingValidated.contains(entry.key)
            }
        }
    }

    /**
     * Extracts iBeacon UUID/major/minor from the manufacturer specific data in the scan result.
     * Returns null if the data cannot be parsed.
     */
    private fun extractBeaconKeyFromScanResult(result: ScanResult): BeaconKey? {
        try {
            // iBeacon manufacturer ID is 0x004C (Apple)
            val manufacturerData = result.scanRecord?.getManufacturerSpecificData(0x004C) ?: return null
            
            // iBeacon format: 0x02 0x15 [16 bytes UUID] [2 bytes major] [2 bytes minor] [1 byte tx power]
            // Minimum length: 1 (type) + 1 (length) + 16 (UUID) + 2 (major) + 2 (minor) + 1 (tx) = 23 bytes
            if (manufacturerData.size < 23) return null
            
            // Check for iBeacon type (0x02) and length (0x15 = 21 bytes following)
            if (manufacturerData[0] != 0x02.toByte() || manufacturerData[1] != 0x15.toByte()) return null
            
            // Extract UUID (bytes 2-17)
            val uuidBytes = manufacturerData.copyOfRange(2, 18)
            val uuid = java.util.UUID(
                java.nio.ByteBuffer.wrap(uuidBytes.copyOfRange(0, 8)).long,
                java.nio.ByteBuffer.wrap(uuidBytes.copyOfRange(8, 16)).long
            )
            
            // Extract major (bytes 18-19)
            val major = ((manufacturerData[18].toInt() and 0xFF) shl 8) or 
                       (manufacturerData[19].toInt() and 0xFF)
            
            // Extract minor (bytes 20-21)
            val minor = ((manufacturerData[20].toInt() and 0xFF) shl 8) or 
                       (manufacturerData[21].toInt() and 0xFF)
            
            "[BIQ][BSM] Extracted iBeacon data: UUID=$uuid, major=$major, minor=$minor".logDebugMessage()
            
            return BeaconKey(uuid, major, minor)
        } catch (e: Exception) {
            "[BIQ][BSM] Failed to extract iBeacon data from scan result: ${e.message}".logWarningMessage()
            return null
        }
    }

}