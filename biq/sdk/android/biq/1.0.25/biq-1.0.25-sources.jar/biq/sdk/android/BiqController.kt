package biq.sdk.android

import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.location.LocationManager
import biq.sdk.android.helpers.ConnectionState
import biq.sdk.android.helpers.extensions.isApiKeyNotValid
import biq.sdk.android.helpers.extensions.isRefreshTokenNotValid
import biq.sdk.android.helpers.extensions.logErrorMessage
import biq.sdk.android.managers.NotificationsManager
import biq.sdk.android.managers.PermissionsManager
import biq.sdk.android.managers.PermissionsManager.PERMISSION_RECEIVE_BOOT_COMPLETED
import biq.sdk.android.managers.beacon.BeaconScannerManager
import biq.sdk.android.managers.bluetooth.BluetoothStateManager
import biq.sdk.android.managers.LogsManager
import biq.sdk.android.managers.location.LocationStateManager
import biq.sdk.android.managers.preferences.DebugPrefsManager
import biq.sdk.android.managers.preferences.PrefsManager
import biq.sdk.android.models.BiqPresenceState
import biq.sdk.android.models.BiqScanningState
import biq.sdk.android.networking.models.EventDto
import biq.sdk.android.providers.ConnectionStateProvider
import biq.sdk.android.providers.ContextProvider
import biq.sdk.android.providers.CoroutineScopeProvider
import biq.sdk.android.providers.DatabaseProvider
import biq.sdk.android.providers.DebugModeProvider
import biq.sdk.android.providers.UserSessionProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext

class BiqController private constructor() {

    interface BiqStateListener {
        fun onSdkStateChanged(newState: BiqPresenceState)
        fun onScanningStateChanged(newState: BiqScanningState)
        fun onValidationRecordsChanged(newRecords: List<EventDto>)
        fun onBluetoothStateChange(isEnabled: Boolean)
        fun onLocationStateChange(isEnabled: Boolean)
    }

    private val beaconScannerManager = BeaconScannerManager()
    private var presenceStateListener: BiqStateListener? = null

    companion object {
        const val TAG = "BiqController"

        @Volatile
        private var INSTANCE: BiqController? = null

        fun getInstance(): BiqController {
            return INSTANCE
                ?: throw IllegalStateException("BiqController is not initialized.")
        }
    }

    class Builder(private val context: Context) {
        fun build(): BiqController {
            synchronized(this) {
                if (INSTANCE == null) {
                    ContextProvider.init(context)
                    DatabaseProvider.init()
                    CoroutineScopeProvider.init()
                    INSTANCE = BiqController()

                    INSTANCE?.registerServicesReceivers()
                }
                return INSTANCE!!
            }
        }
    }

    // USER SESSION

    /***
     * Load the current user session.
     */
    fun init(apiKey: String, refreshToken: String): Boolean {
        if (apiKey.isApiKeyNotValid() || refreshToken.isRefreshTokenNotValid()) {
            return false
        }

        CoroutineScopeProvider.get().launch {
            UserSessionProvider.init(
                apiKey = apiKey,
                refreshToken = refreshToken
            )
        }

        return true
    }

    /***
     * Clear the current session.
     */
    suspend fun logOut(): Boolean {
        UserSessionProvider.logout()
        stopPresence()
        return true
    }

    // NOTIFICATIONS

    /***
     * This activity will be used as entry point when the notification is clicked.
     */
    fun setNotificationEntryPoint(targetActivity: Class<out Activity>) = apply {
        NotificationsManager.configure(targetActivity)
    }

    /***
     * Initialize notification data. Host app can define title and message for scanning and proximity notifications.
     */
    fun initNotificationData(
        iconResId: Int? = null,
        scanningNotificationTitle: String? = null,
        scanningNotificationMessage: String? = null,
        proximityNotificationTitle: String? = null,
        proximityNotificationMessage: String? = null
    ) = apply {
        NotificationsManager.initNotificationData(
            iconResId = iconResId,
            scanningNotificationTitle = scanningNotificationTitle,
            scanningNotificationMessage = scanningNotificationMessage,
            proximityNotificationTitle = proximityNotificationTitle,
            proximityNotificationMessage = proximityNotificationMessage
        )
    }

    fun setProximityNotificationAvailability(
        isProximityNotificationAvailable: Boolean,
    ) = apply {
        CoroutineScopeProvider.get().launch {
            PrefsManager.saveNotificationAvailabilityPreference(isProximityNotificationAvailable)
        }
    }

    // PRESENCE HANDLER

    fun setBootAutoScan(
        isStartAfterBoot: Boolean,
    ) = apply {
        if (!PermissionsManager.isBootPermissionDeclared()) {
            throw IllegalStateException("$PERMISSION_RECEIVE_BOOT_COMPLETED permission is not declared in manifest")
        }

        CoroutineScopeProvider.get().launch {
            PrefsManager.saveStartAfterBootPreference(isStartAfterBoot)
        }
    }

    /***
     * Start monitoring and ranging beacons, if not already started.
     * This should be called by the host app to enable presence detection.
     */
    fun startPresence(): ConnectionState {
        CoroutineScopeProvider.get().launch {
            PrefsManager.saveStartedByHostApp(true)
        }
        return startPresence(isStartedByHostApp = true)
    }

    internal fun startPresence(isStartedByHostApp: Boolean): ConnectionState {
        if (!isStartedByHostApp) {
            val wasStartedByHostApp = runBlocking {
                PrefsManager.getStartedByHostApp()
            }
            
            if (!wasStartedByHostApp) {
                "[BIQ] Host app did not start presence yet. Please call BiqController.startPresence() from the host app first.".logErrorMessage()
                return ConnectionState.Error(
                    state = BiqPresenceState.SCANNING_NOT_STARTED
                )
            }
        }
        
        return beaconScannerManager.startScanning()
    }

    /***
     * Stop any ongoing process related with presence detection.
     * It includes:
     * - beacon ranging and monitoring;
     * - bluetooth state receiver;
     * - bluetooth scanning and connection;
     * - biq coroutine provider that controls the multithreading work;
     * - cancel pinned scanning notification;
     * - unregister network connectivity manager.
     */
    fun stopPresence() {
        CoroutineScopeProvider.get().launch {
            PrefsManager.saveStartedByHostApp(false)
        }
        beaconScannerManager.stopScanning()
    }

    fun forcePresenceRanging() {
        beaconScannerManager.resumeScanning(isForced = true)
    }

    // PERMISSIONS

    /***
     * Check if all required permissions are granted.
     */
    fun areAllPermissionsGranted() = PermissionsManager.getMissingPermission() == null

    /***
     * Get first missing permission encountered.
     */
    fun getMissingPermission() = PermissionsManager.getMissingPermission()

    // STATES

    /***
     * Get current scanning state.
     */
    fun getScanningState() = ConnectionStateProvider.scanningState

    /***
     * Get general SDK state.
     */
    fun getSdkState() = ConnectionStateProvider.state

    fun isBluetoothEnabled() = BluetoothAdapter.getDefaultAdapter()?.isEnabled
        ?: false // Bluetooth not supported by device

    fun isLocationEnabled(): Boolean {
        val locationManager = ContextProvider.get().getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        return locationManager?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true
            || locationManager?.isProviderEnabled(LocationManager.NETWORK_PROVIDER) == true
    }

    /**
     * Check if both bluetooth and location services are enabled.
     * Both are required for scanning to work properly.
     */
    fun areRequiredServicesEnabled(): Boolean {
        val isOk = isBluetoothEnabled() && isLocationEnabled()
        "[BIQ] Required services enabled: $isOk".logErrorMessage()
        return isOk
    }

    fun setPresenceStateListener(stateListener: BiqStateListener?) {
        this.presenceStateListener = stateListener
    }

    internal fun notifyStateChange(newState: BiqPresenceState) {
        this.presenceStateListener?.onSdkStateChanged(newState)
    }

    internal fun notifyScanningChange(newState: BiqScanningState) {
        this.presenceStateListener?.onScanningStateChanged(newState)
    }

    internal fun notifyValidationRecordsChange(newRecords: List<EventDto>) {
        this.presenceStateListener?.onValidationRecordsChanged(newRecords)
    }

    internal fun notifyBluetoothStateChange(isEnabled: Boolean) {
        if(!isEnabled) {
            beaconScannerManager.pauseScanning()
        } else {
            beaconScannerManager.resumeScanning(isForced = true)
        }

        this.presenceStateListener?.onBluetoothStateChange(isEnabled)
    }

    internal fun notifyLocationStateChange(isEnabled: Boolean) {
        if(!isEnabled) {
            beaconScannerManager.pauseScanning()
        } else {
            beaconScannerManager.resumeScanning(isForced = true)
        }

        this.presenceStateListener?.onLocationStateChange(isEnabled)
    }

    // SERVICES

    fun registerServicesReceivers() {
        registerBluetoothStateReceiver()
        registerLocationStateReceiver()
    }

    fun unregisterReceivers() {
        unregisterBluetoothStateReceiver()
        unregisterLocationStateReceiver()
    }

    // SERVICES: BLUETOOTH

    fun registerBluetoothStateReceiver() {
        BluetoothStateManager.register(ContextProvider.get())
    }

    fun unregisterBluetoothStateReceiver() {
        BluetoothStateManager.unregister(ContextProvider.get())
    }

    // SERVICES: LOCATION

    fun registerLocationStateReceiver() {
        LocationStateManager.register(ContextProvider.get())
    }

    fun unregisterLocationStateReceiver() {
        LocationStateManager.unregister(ContextProvider.get())
    }

    // DATABASE RECORDS

    suspend fun getValidationRecords() = withContext(Dispatchers.IO) {
        DatabaseProvider.getEventRepository().getAll()
    }

    // DEBUG MODE

    fun setDebugMode(isDebugModeEnabled: Boolean) = apply {
        DebugModeProvider.init(isDebugModeEnabled)
    }

    /***
     * Get validation records from debug prefs.
     */
    @Deprecated("Will soon be removed. Use BiqController.getInstance().shareLogs() instead.")
    suspend fun loadDebugValidationRecords(): String? {
        if (DebugModeProvider.isDebugOff) {
            "[BIQ] Activate debug mode by calling setDebugMode() with true.".logErrorMessage(
                tag = TAG,
                isForced = true
            )
            return null
        }

        return DebugPrefsManager.getValidationsRecords()
    }

    /***
     * Remove validation records from debug prefs.
     */
    @Deprecated("Will soon be removed. Use BiqController.getInstance().shareLogs() instead.")
    fun removeDebugValidationRecords() {
        if (DebugModeProvider.isDebugOff) {
            "[BIQ] Activate debug mode by calling setDebugMode() with true.".logErrorMessage(
                tag = TAG,
                isForced = true
            )
            return
        }

        CoroutineScopeProvider.get().launch {
            DebugPrefsManager.removeValidationsRecords()
        }
    }

    fun shareLogs(): Boolean {
        return LogsManager.shareLogs()
    }
}
