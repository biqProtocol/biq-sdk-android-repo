package biq.sdk.android.managers.beacon

import biq.sdk.android.BiqController
import biq.sdk.android.helpers.extensions.logDebugMessage
import biq.sdk.android.helpers.extensions.logErrorMessage
import biq.sdk.android.managers.NetworkConnectivityManager
import biq.sdk.android.managers.bluetooth.BluetoothCommunicationManager.BEACON_UUID
import biq.sdk.android.providers.ContextProvider
import com.davidgyoungtech.beaconparsers.IBeaconParser
import org.altbeacon.beacon.BeaconManager
import org.altbeacon.beacon.BeaconRegion
import org.altbeacon.beacon.MonitorNotifier

internal class BeaconUtils {

    private val context get() = ContextProvider.get()
    private val beaconManager get() = BeaconManager.getInstanceForApplication(context)

    @Volatile
    var isInsideRegion = false
        private set

    val iBeaconRegion = BeaconRegion(
        "everyIBeaconRegion",
        IBeaconParser(),
        BEACON_UUID.toString(),
        null,
        null
    )

    fun startRangingBeacons() {
        if(!NetworkConnectivityManager.isConnected()) {
            "[BIQ][BU] No internet connection to start ranging.".logErrorMessage()
            return
        }

        if(!BiqController.getInstance().isBluetoothEnabled()) {
            "[BIQ][BU] Bluetooth not available to start ranging.".logErrorMessage()
            return
        }

        if(!BiqController.getInstance().isLocationEnabled()) {
            "[BIQ][BU] Location services not available to start ranging.".logErrorMessage()
            return
        }

        // Force stop first, then restart to ensure clean BLE state after GATT operations
        if (beaconManager.rangedRegions.contains(iBeaconRegion)) {
            "[BIQ][BU] Force-stopping ranging before restart to ensure clean BLE state.".logDebugMessage()
            beaconManager.stopRangingBeacons(iBeaconRegion)
        }
        beaconManager.startRangingBeacons(iBeaconRegion)
    }

    /**
     * Force restart both monitoring and ranging to recover from BLE stack degradation.
     * This should be called when consecutive zero-beacon ranging callbacks are detected
     * AND no beacon has been found in the current session.
     * Restarting monitoring triggers an INSIDE event which helps full recovery.
     */
    fun forceRestartRanging() {
        "[BIQ][BU] Force restarting monitoring and ranging due to consecutive zero-beacon callbacks.".logDebugMessage()
        
        // Stop everything first
        if (beaconManager.rangedRegions.contains(iBeaconRegion)) {
            beaconManager.stopRangingBeacons(iBeaconRegion)
        }
        if (beaconManager.monitoredRegions.contains(iBeaconRegion)) {
            beaconManager.stopMonitoring(iBeaconRegion)
        }
        
        // Restart monitoring and ranging
        // Keep isInsideRegion = true so the ranging loop continues
        beaconManager.startMonitoring(iBeaconRegion)
        beaconManager.startRangingBeacons(iBeaconRegion)
    }

    fun stopRangingBeacons() {
        if (beaconManager.rangedRegions.contains(iBeaconRegion)) {
            beaconManager.stopRangingBeacons(iBeaconRegion)
        }
    }

    fun startMonitoringBeacon() {
        if (!beaconManager.monitoredRegions.contains(iBeaconRegion)) {
            isInsideRegion = false
            beaconManager.startMonitoring(iBeaconRegion)
        }
    }

    fun stopMonitoringBeacon() {
        if (beaconManager.monitoredRegions.contains(iBeaconRegion)) {
            beaconManager.stopMonitoring(iBeaconRegion)
            isInsideRegion = false
        }
    }

    fun onMonitorNotifier(state: Int) {
        isInsideRegion = when (state == MonitorNotifier.OUTSIDE) {
            true -> false
            else -> true
        }
    }

    /**
     * Checks if monitoring is currently active for our beacon region.
     * Used by the health check to detect if the foreground service has stopped unexpectedly.
     */
    fun isMonitoringActive(): Boolean {
        return beaconManager.monitoredRegions.contains(iBeaconRegion)
    }

    /**
     * Restarts monitoring if it has stopped unexpectedly.
     * This helps recover from situations where the foreground service was killed.
     * @return true if monitoring was restarted, false if it was already active
     */
    fun ensureMonitoringActive(): Boolean {
        if (!isMonitoringActive()) {
            "[BIQ][BU] Monitoring was not active, restarting...".logDebugMessage()
            beaconManager.startMonitoring(iBeaconRegion)
            return true
        }
        return false
    }
}
