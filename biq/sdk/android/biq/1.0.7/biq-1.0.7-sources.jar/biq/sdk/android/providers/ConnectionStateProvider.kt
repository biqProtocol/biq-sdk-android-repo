package biq.sdk.android.providers

import biq.sdk.android.BiqController
import biq.sdk.android.managers.NetworkConnectivityManager
import biq.sdk.android.models.BiqNetworkState
import biq.sdk.android.models.BiqPresenceState
import biq.sdk.android.models.BiqScanningState

internal object ConnectionStateProvider {
    var state: BiqPresenceState = BiqPresenceState.UNKNOWN
        private set
        get() = when (NetworkConnectivityManager.isConnected()) {
            true -> field
            else -> BiqPresenceState.NETWORK_ERROR
        }

    var scanningState: BiqScanningState = BiqScanningState.UNKNOWN
        private set

    fun updateState(state: BiqPresenceState) {
        this.state = state

        when (state) {
            BiqPresenceState.SCANNING_IN_PROGRESS -> updateScanningState(BiqScanningState.SCANNING_IN_PROGRESS)
            BiqPresenceState.SCANNING_NOT_STARTED -> updateScanningState(BiqScanningState.SCANNING_NOT_STARTED)
            else -> Unit
        }

        BiqController.getInstance().notifyStateChange(state)
    }

    private fun updateScanningState(state: BiqScanningState) {
        this.scanningState = state

        BiqController.getInstance().notifyScanningChange(state)
    }
}
