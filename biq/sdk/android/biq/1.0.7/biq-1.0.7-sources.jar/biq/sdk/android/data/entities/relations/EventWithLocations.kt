package biq.sdk.android.data.entities.relations

import androidx.room.Embedded
import androidx.room.Relation
import biq.sdk.android.data.entities.EventEntity
import biq.sdk.android.data.entities.EventLocationEntity
import biq.sdk.android.networking.models.PresenceProofResponseDto

data class EventWithLocations(
    @Embedded val event: EventEntity,
    @Relation(
        parentColumn = EventEntity.COLUMN_ID,
        entityColumn = EventLocationEntity.COLUMN_EVENT_ID
    )
    val locations: List<EventLocationEntity>
)