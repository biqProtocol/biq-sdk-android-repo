package biq.sdk.android.data.repositories.event

import biq.sdk.android.networking.models.PresenceProofResponseDto

internal interface EventDataRepository {
    suspend fun insertAll(dtoList: List<PresenceProofResponseDto>)
    suspend fun getAll(): List<PresenceProofResponseDto>
    suspend fun deleteAll()
}