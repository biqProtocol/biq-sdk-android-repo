package biq.sdk.android.data.repositories.event

import biq.sdk.android.data.dao.EventAreaDao
import biq.sdk.android.data.dao.EventDao
import biq.sdk.android.data.dao.EventLocationDao
import biq.sdk.android.data.entities.EventAreaEntity
import biq.sdk.android.data.entities.EventLocationEntity
import biq.sdk.android.data.entities.relations.toDto
import biq.sdk.android.data.entities.toDto
import biq.sdk.android.networking.models.PresenceProofResponseDto
import biq.sdk.android.networking.models.toEntity

internal class EventDataRepositoryLocal(
    private val eventDao: EventDao,
    private val eventLocationDao: EventLocationDao,
    private val eventAreaDao: EventAreaDao
) : EventDataRepository {
    override suspend fun insertAll(dtoList: List<PresenceProofResponseDto>) {
        val locations = mutableListOf<EventLocationEntity>()
        val areas = mutableListOf<EventAreaEntity>()

        dtoList.forEach { event ->
            event.locations?.map { location ->
                location.areas?.map { area ->
                    area.toEntity(location.id)
                }?.let {
                    areas.addAll(it)
                }
                location.toEntity(event.id)
            }?.let {
                locations.addAll(it)
            }
        }

        eventDao.insertAll(dtoList.map { it.toEntity() })
        eventLocationDao.insertAll(locations)
        eventAreaDao.insertAll(areas)
    }

    override suspend fun getAll() = eventDao.getEventsWithLocationsAndAreas().map { it.toDto() }

    override suspend fun deleteAll() {
        eventDao.deleteAll()
        eventLocationDao.deleteAll()
        eventAreaDao.deleteAll()
    }
}