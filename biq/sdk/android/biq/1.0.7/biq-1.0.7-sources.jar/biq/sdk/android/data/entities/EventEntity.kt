package biq.sdk.android.data.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import biq.sdk.android.networking.models.PresenceProofResponseDto

@Entity(tableName = "eventEntity")
data class EventEntity(
    @PrimaryKey
    @ColumnInfo(name = COLUMN_ID)
    val id: String,
    val type: String,
    val name: String,
    val description: String,
    val image: String,
    val organizer: String?,
    val url: String?,
    val startTime: Long?,
    val endTime: Long?,
    val isPublic: Boolean?,
    val isGated: Boolean?,
    val tags: List<String>?,
    val owners: List<String>?
) {
    companion object {
        const val COLUMN_ID = "id"
    }
}