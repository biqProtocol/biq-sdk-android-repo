package biq.sdk.android.providers

import androidx.room.Room
import biq.sdk.android.BuildConfig
import biq.sdk.android.data.AppDatabase
import biq.sdk.android.data.repositories.event.EventDataRepository
import biq.sdk.android.data.repositories.event.EventDataRepositoryLocal

internal object DatabaseProvider {

    private const val DATABASE_NAME = "biq_sdk_database"

    private var database: AppDatabase? = null
    private var eventRepo: EventDataRepository? = null

    fun init() {
        if (database != null) return // already initialized

        database = Room.databaseBuilder(
            ContextProvider.get(),
            AppDatabase::class.java,
            DATABASE_NAME
        ).apply {
            if (BuildConfig.DEBUG) {
                // Be careful to not use fallback in production and use real migrations
                fallbackToDestructiveMigration()
            }
        }.build()

        eventRepo = EventDataRepositoryLocal(
            eventDao = database!!.eventDao,
            eventLocationDao = database!!.eventLocationDao,
            eventAreaDao = database!!.eventAreaDao
        )
    }

    fun getDatabase(): AppDatabase {
        checkNotNull(database) { "DatabaseProvider.init(context) must be called first" }
        return database!!
    }

    fun getEventRepository(): EventDataRepository {
        checkNotNull(eventRepo) { "DatabaseProvider.init(context) must be called first" }
        return eventRepo!!
    }
}