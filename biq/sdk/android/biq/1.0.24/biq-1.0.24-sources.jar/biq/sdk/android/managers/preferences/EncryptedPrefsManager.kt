package biq.sdk.android.managers.preferences

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import biq.sdk.android.helpers.extensions.logWarningMessage
import biq.sdk.android.providers.ContextProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private val Context.encryptedDataStore by preferencesDataStore(name = "encrypted-biq-sdk-prefs")

internal object EncryptedPrefsManager {

    private const val TAG = "EncryptedPrefsManager"
    private const val KEY_ALIAS = "biq_secure_key"
    private const val ANDROID_KEY_STORE = "AndroidKeyStore"

    private const val ACCESS_TOKEN_KEY = "accessToken"
    private const val REFRESH_TOKEN_KEY = "refreshToken"
    private const val API_KEY = "apiKey"

    private const val AES_MODE = "AES/GCM/NoPadding"
    private const val IV_SUFFIX = "_iv"
    private const val GCM_TAG_LENGTH = 128

    private val context: Context get() = ContextProvider.get()

    init {
        ensureKeyExists()
    }

    private fun ensureKeyExists() {
        val keyStore = KeyStore.getInstance(ANDROID_KEY_STORE).apply { load(null) }

        if (!keyStore.containsAlias(KEY_ALIAS)) {
            val keyGenerator = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES,
                ANDROID_KEY_STORE
            )
            val keyGenSpec = KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()

            keyGenerator.init(keyGenSpec)
            keyGenerator.generateKey()
        }
    }

    private fun getSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEY_STORE).apply { load(null) }
        return (keyStore.getEntry(KEY_ALIAS, null) as KeyStore.SecretKeyEntry).secretKey
    }

    private fun encrypt(value: String): Pair<String, String> {
        val cipher = Cipher.getInstance(AES_MODE)
        cipher.init(Cipher.ENCRYPT_MODE, getSecretKey())
        val iv = cipher.iv
        val encryptedBytes = cipher.doFinal(value.toByteArray())
        val encryptedBase64 = Base64.encodeToString(encryptedBytes, Base64.NO_WRAP)
        val ivBase64 = Base64.encodeToString(iv, Base64.NO_WRAP)
        return encryptedBase64 to ivBase64
    }

    private fun decrypt(encrypted: String, iv: String): String {
        val cipher = Cipher.getInstance(AES_MODE)
        val ivBytes = Base64.decode(iv, Base64.NO_WRAP)
        val spec = GCMParameterSpec(GCM_TAG_LENGTH, ivBytes)
        cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), spec)
        val decoded = Base64.decode(encrypted, Base64.NO_WRAP)
        return String(cipher.doFinal(decoded))
    }

    suspend fun saveEncrypted(key: String, value: String) = withContext(Dispatchers.IO) {
        val (encrypted, iv) = encrypt(value)
        context.encryptedDataStore.edit { prefs ->
            prefs[stringPreferencesKey(key)] = encrypted
            prefs[stringPreferencesKey(key + IV_SUFFIX)] = iv
        }
    }

    suspend fun getDecrypted(key: String): String? = withContext(Dispatchers.IO) {
        val prefs = context.encryptedDataStore.data.first()
        val encrypted = prefs[stringPreferencesKey(key)]
        val iv = prefs[stringPreferencesKey(key + IV_SUFFIX)]
        if (encrypted != null && iv != null) {
            try {
                decrypt(encrypted, iv)
            } catch (e: Exception) {
                "[BIQ][EPM] Decryption failed for key '$key', clearing corrupted data: ${e.message}".logWarningMessage(TAG)
                context.encryptedDataStore.edit { editPrefs ->
                    editPrefs.remove(stringPreferencesKey(key))
                    editPrefs.remove(stringPreferencesKey(key + IV_SUFFIX))
                }
                null
            }
        } else {
            null
        }
    }

    suspend fun remove(key: String) = withContext(Dispatchers.IO) {
        context.encryptedDataStore.edit { prefs ->
            prefs.remove(stringPreferencesKey(key))
            prefs.remove(stringPreferencesKey(key + IV_SUFFIX))
        }
    }

    suspend fun saveAccessToken(token: String) = saveEncrypted(ACCESS_TOKEN_KEY, token)
    suspend fun getAccessToken(): String? = getDecrypted(ACCESS_TOKEN_KEY)
    suspend fun removeAccessToken() = remove(ACCESS_TOKEN_KEY)

    suspend fun saveRefreshToken(token: String) = saveEncrypted(REFRESH_TOKEN_KEY, token)
    suspend fun getRefreshToken(): String? = getDecrypted(REFRESH_TOKEN_KEY)
    suspend fun removeRefreshToken() = remove(REFRESH_TOKEN_KEY)

    suspend fun saveApiKey(apiKey: String) = saveEncrypted(API_KEY, apiKey)
    suspend fun getApiKey(): String? = getDecrypted(API_KEY)
    suspend fun removeApiKey() = remove(API_KEY)
}

