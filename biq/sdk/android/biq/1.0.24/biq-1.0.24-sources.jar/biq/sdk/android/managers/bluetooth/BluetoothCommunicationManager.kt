package biq.sdk.android.managers.bluetooth

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import androidx.annotation.RequiresPermission
import biq.sdk.android.BiqController
import biq.sdk.android.BuildConfig
import biq.sdk.android.helpers.extensions.logDebugMessage
import biq.sdk.android.helpers.extensions.logErrorMessage
import biq.sdk.android.helpers.extensions.logInfoMessage
import biq.sdk.android.helpers.extensions.logWarningMessage
import biq.sdk.android.helpers.utils.Base58
import biq.sdk.android.managers.beacon.BeaconScannerManager
import biq.sdk.android.managers.preferences.DebugPrefsManager
import biq.sdk.android.models.BiqPresenceState
import biq.sdk.android.models.BiqScanningState
import biq.sdk.android.networking.models.PresenceProofRequestDto
import biq.sdk.android.networking.models.EventDto
import biq.sdk.android.networking.models.PresenceProofResponseDto
import biq.sdk.android.networking.repositories.PresenceProofServiceRepository
import biq.sdk.android.providers.ConnectionStateProvider
import biq.sdk.android.providers.ContextProvider
import biq.sdk.android.providers.DatabaseProvider
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.time.Duration
import java.time.LocalDateTime
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi

// TODO take a second look over deprecations
@Suppress("Deprecation")
internal object BluetoothCommunicationManager {
    private const val TAG = "BluetoothCommunicationManager"

    /***
     *  standard Bluetooth SIG‑assigned UUID for the Client Characteristic Configuration
     *  Descriptor (CCCD), which is used to enable or disable notifications/indications
     *  on a characteristic. In the BLE specification, descriptors live under the “0x2900”
     *  series, and 0x2902 specifically is the CCCD.
     */
    private val CLIENT_CHARACTERISTIC_CONFIG_UUID =
        UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    val BEACON_UUID: UUID = UUID.fromString("2c1cb000-fd03-4b10-a8f9-325096b39f47")
    private val SERVICE_UUID: UUID = UUID.fromString("2c1cb000-fd03-4b10-a8f9-325096b39f47")
    private val INFO_UUID: UUID = UUID.fromString("2c1cb001-fd03-4b10-a8f9-325096b39f47")
    private val TX_UUID: UUID = UUID.fromString("2c1cb003-fd03-4b10-a8f9-325096b39f47")
    private val RX_UUID: UUID = UUID.fromString("2c1cb002-fd03-4b10-a8f9-325096b39f47")

    data class PeripheralSignature(
        val uuid: String,
        val major: Int,
        val minor: Int,
        val publicKey: String,
        val signature: String
    )

    private val perDeviceMutex = ConcurrentHashMap<String, Mutex>()

    private val nonceCacheMutex = Mutex()
    private data class CachedNonce(
        val nonce: String,
        val timestamp: LocalDateTime
    )
    private var cachedNonce: CachedNonce? = null

    private const val NONCE_VALIDITY_SECONDS = 26L
    private const val VALIDATION_FLOW_TIMEOUT_MS = 20_000L
    private const val VALIDATION_BATCH_DELAY_MS = 10_000L

    private var validationScopeJob: Job = SupervisorJob()
    private var validationScope = CoroutineScope(validationScopeJob + Dispatchers.IO)
    private val validationQueueMutex = Mutex()
    private val validationQueue = mutableListOf<PendingValidation>()
    private var validationDispatchJob: Job? = null
    private var validationWindowClosed = false

    private data class PendingValidation(
        val request: PresenceProofRequestDto,
        val macAddress: String,
        val deferred: CompletableDeferred<PresenceProofResponseDto>
    )

    // Track devices being validated by MAC address
    private val devicesBeingValidated = ConcurrentHashMap.newKeySet<String>()
    private val devicesUsedForValidation = ConcurrentHashMap.newKeySet<String>()

    /**
     * Handles a detected BLE device for validation.
     * Each physical device (identified by MAC address) is validated independently,
     * even if multiple devices share the same BeaconKey (UUID/major/minor).
     */
    @OptIn(ExperimentalEncodingApi::class)
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    suspend fun handleDetectedDevice(
        device: BluetoothDevice,
        beaconKey: BeaconScannerManager.BeaconKey
    ) = coroutineScope {
        val macAddress = device.address

        // Check if this device has already been used for validation in this cycle
        if (!devicesUsedForValidation.add(macAddress)) {
            "[BIQ][BCM] Device $macAddress has already been used for validation, skipping".logDebugMessage()
            return@coroutineScope
        }

        val restrictionMinutes = when (BuildConfig.DEBUG) {
            true -> 1L
            else -> BeaconScannerManager.Companion.VALIDATION_RESTRICTION_MINUTES
        }

        // Check if this specific device is available for validation
        val deviceInfo = BluetoothScannerManager.findAvailableDevice(
            macAddress = macAddress,
            devicesBeingValidated = devicesBeingValidated,
            restrictionMinutes = restrictionMinutes
        )

        if (deviceInfo == null) {
            // Device not recorded yet - record it now and proceed
            BluetoothScannerManager.recordDeviceToConnect(macAddress, beaconKey)
        }

        // Check if already being validated
        if (!devicesBeingValidated.add(macAddress)) {
            devicesUsedForValidation.remove(macAddress)
            "[BIQ][BCM] Device $macAddress is already being validated, skipping".logWarningMessage()
            return@coroutineScope
        }

        launch {
            val deviceMutex = perDeviceMutex.getOrPut(macAddress) { Mutex() }

            deviceMutex.withLock {
                val isWindowClosed = validationQueueMutex.withLock { validationWindowClosed }
                if (isWindowClosed) {
                    "[BIQ][BCM] Skipping validation because batching window is closed for device=$macAddress".logWarningMessage()
                    devicesBeingValidated.remove(macAddress)
                    return@withLock
                }

                val timedOut = withTimeoutOrNull(VALIDATION_FLOW_TIMEOUT_MS) {
                    ("[BIQ][BCM] Nonce signing&validation process started at: ${LocalDateTime.now()}, " +
                            "for uuid=${beaconKey.uuid}, " +
                            "major=${beaconKey.major}, " +
                            "minor=${beaconKey.minor}, " +
                            "device=$macAddress").logInfoMessage()

                    DebugPrefsManager.saveValidationStateTimestamp(true)
                    ConnectionStateProvider.updateState(BiqPresenceState.VALIDATION_IN_PROGRESS)

                    val nonce = try {
                        val base64Nonce = getNonce()
                        Base64.decode(base64Nonce)
                    } catch (e: Exception) {
                        "[BIQ][BCM] Failed to get nonce: ${e.message}".apply {
                            logErrorMessage()
                            DebugPrefsManager.saveValidationLog(this)
                        }
                        updateScanningInProgressIfNotPaused()
                        return@withTimeoutOrNull
                    }

                    try {
                        val signature = retryBLE(times = 1) {
                            device.signNonceForDevice(
                                nonce = nonce,
                                beaconKey = beaconKey
                            )
                        }

                        // Send signature and wait for batch validation
                        sendSignature(signature, macAddress)

                        // Update device-specific state
                        BluetoothScannerManager.updateValidatedDevice(macAddress)
                        DebugPrefsManager.saveValidationStateTimestamp(isStarted = false, isSuccess = true)
                    } catch (e: Exception) {
                        "[BIQ][BCM] BLE validation failed for device $macAddress: ${e.message}".logErrorMessage()
                        DebugPrefsManager.saveValidationStateTimestamp(isStarted = false, isSuccess = false)
                    } finally {
                        devicesBeingValidated.remove(macAddress)
                        ("[BIQ][BCM] Nonce signing&validation process finished at: ${LocalDateTime.now()}, " +
                                "for uuid=${beaconKey.uuid}, " +
                                "major=${beaconKey.major}, " +
                                "minor=${beaconKey.minor}, " +
                                "device=$macAddress").logInfoMessage()
                        if (devicesBeingValidated.isEmpty()) {
                            updateScanningInProgressIfNotPaused()
                        }
                    }
                }

                if (timedOut == null) {
                    devicesBeingValidated.remove(macAddress)
                    ("[BIQ][BCM] Validation timed out after ${VALIDATION_FLOW_TIMEOUT_MS / 1000}s " +
                            "for uuid=${beaconKey.uuid}, major=${beaconKey.major}, minor=${beaconKey.minor}, " +
                            "device=$macAddress").logWarningMessage()
                    DebugPrefsManager.saveValidationStateTimestamp(isStarted = false, isSuccess = false)
                    if (devicesBeingValidated.isEmpty()) {
                        updateScanningInProgressIfNotPaused()
                    }
                }
            }
        }
    }

    /**
     * Signs a nonce using the device's BLE GATT service.
     */
    @SuppressLint("MissingPermission")
    private suspend fun BluetoothDevice.signNonceForDevice(
        nonce: ByteArray,
        beaconKey: BeaconScannerManager.BeaconKey
    ): PeripheralSignature = withContext(Dispatchers.IO) {
        val callback = GattCoroutineCallback()
        val gatt = connectGatt(ContextProvider.get(), false, callback)
        val beaconLabel = "uuid=${beaconKey.uuid}, major=${beaconKey.major}, minor=${beaconKey.minor}, device=$address"

        ("[BIQ][BCM] Signing started for $beaconLabel").logInfoMessage()
        try {
            // 1. Wait for connect
            "[BIQ][BCM] Signing step 1/9: awaiting GATT connection ($beaconLabel)".logInfoMessage()
            callback.awaitConnection()

            // 2. Request MTU
            "[BIQ][BCM] Signing step 2/9: requesting MTU=517 ($beaconLabel)".logInfoMessage()
            callback.prepareMtu()
            gatt.requestMtu(517)
            callback.awaitMtu()

            // 3. Discover services
            "[BIQ][BCM] Signing step 3/9: discovering services ($beaconLabel)".logInfoMessage()
            callback.prepareServices()
            gatt.discoverServices()
            callback.awaitServices()

            val service = gatt.getService(SERVICE_UUID)
                ?: error("Service missing")
            val infoChar = service.getCharacteristic(INFO_UUID)
                ?: error("Info char missing")
            val rxChar = service.getCharacteristic(RX_UUID)
                ?: error("RX char missing")
            val txChar = service.getCharacteristic(TX_UUID)
                ?: error("TX char missing")

            // 4. Read public key
            "[BIQ][BCM] Signing step 4/9: reading peripheral public key ($beaconLabel)".logInfoMessage()
            val readDef = callback.prepareRead(infoChar.uuid)
            gatt.readCharacteristic(infoChar)
            val pkBytes = readDef.await()
            val pkBs58 = Base58.encode(pkBytes)
            // Update the device info with the public key
            BluetoothScannerManager.foundDevicesToConnect[address]?.publicKey = pkBs58
            "[BIQ][BCM] Signing step 4/9: public key length=${pkBs58.length}, key=$pkBs58 ($beaconLabel)".logDebugMessage()

            // 5. Enable notifications
            "[BIQ][BCM] Signing step 5/9: enabling notifications ($beaconLabel)".logInfoMessage()
            val cccd = rxChar.getDescriptor(CLIENT_CHARACTERISTIC_CONFIG_UUID)
                ?: error("CCCD not found")
            val descDef = callback.prepareDescriptor(cccd)
            gatt.setCharacteristicNotification(rxChar, true)
            cccd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            gatt.writeDescriptor(cccd)
            try {
                descDef.await()
            } catch (e: Exception) {
                error("CCCD write failed: ${e.message}")
            }

            // 6. Prepare notification listener BEFORE writing the nonce
            "[BIQ][BCM] Signing step 6/9: preparing notification listener ($beaconLabel)".logInfoMessage()
            val notifyDef = callback.prepareNotify(rxChar)

            // 7. Write nonce
            "[BIQ][BCM] Signing step 7/9: writing nonce to peripheral ($beaconLabel)".logInfoMessage()
            val writeDef = callback.prepareWrite(txChar.uuid)
            txChar.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            txChar.value = nonce
            gatt.writeCharacteristic(txChar)
            writeDef.await()

            // 8. Await signature notification
            "[BIQ][BCM] Signing step 8/9: awaiting signature notification ($beaconLabel)".logInfoMessage()
            val sigBytes = withTimeoutOrNull(3000L) {
                notifyDef.await()
            } ?: error("Timed out waiting for signature notification")
            val sigBs58 = Base58.encode(sigBytes)
            "[BIQ][BCM] Signing step 8/9: signature received length=${sigBytes.size} ($beaconLabel)".logDebugMessage()

            // 9. Build result
            "[BIQ][BCM] Signing step 9/9: building signature payload ($beaconLabel)".logInfoMessage()
            PeripheralSignature(
                uuid = beaconKey.uuid.toString(),
                major = beaconKey.major,
                minor = beaconKey.minor,
                publicKey = pkBs58,
                signature = sigBs58
            )
        } finally {
            try {
                gatt.disconnect()
            } catch (_: Exception) {
            }

            gatt.close()
        }
    }

    private class GattCoroutineCallback : BluetoothGattCallback() {
        private val connectDeferred = CompletableDeferred<BluetoothGatt>()
        private val mtuDeferred = CompletableDeferred<Int>()
        private val svcDeferred = CompletableDeferred<Unit>()
        private val readMap = mutableMapOf<UUID, CompletableDeferred<ByteArray>>()
        private val writeMap = mutableMapOf<UUID, CompletableDeferred<Unit>>()
        private val descriptorMap =
            mutableMapOf<BluetoothGattDescriptor, CompletableDeferred<Unit>>()
        private val notifyMap = mutableMapOf<UUID, CompletableDeferred<ByteArray>>()

        @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
                connectDeferred.complete(gatt)
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                connectDeferred.completeExceptionally(
                    IllegalStateException("Disconnected")
                )
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                mtuDeferred.complete(mtu)
            } else {
                mtuDeferred.completeExceptionally(
                    RuntimeException("MTU failed $status")
                )
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                svcDeferred.complete(Unit)
            } else {
                svcDeferred.completeExceptionally(
                    RuntimeException("Discover failed $status")
                )
            }
        }

        @Deprecated("Deprecated in Java")
        override fun onCharacteristicRead(
            gatt: BluetoothGatt,
            char: BluetoothGattCharacteristic, status: Int
        ) {
            readMap.remove(char.uuid)?.also { deferred ->
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    deferred.complete(char.value)
                } else {
                    deferred.completeExceptionally(
                        RuntimeException("Read failed $status")
                    )
                }
            }
        }

        override fun onDescriptorWrite(
            gatt: BluetoothGatt,
            descriptor: BluetoothGattDescriptor,
            status: Int
        ) {
            descriptorMap.remove(descriptor)?.also { deferred ->
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    deferred.complete(Unit)
                } else {
                    deferred.completeExceptionally(
                        RuntimeException("Descriptor write failed $status")
                    )
                }
            }
        }

        override fun onCharacteristicWrite(
            gatt: BluetoothGatt,
            char: BluetoothGattCharacteristic,
            status: Int
        ) {
            writeMap.remove(char.uuid)?.also { deferred ->
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    deferred.complete(Unit)
                } else {
                    deferred.completeExceptionally(
                        RuntimeException("Write failed $status")
                    )
                }
            }
        }

        @Deprecated("Deprecated in Java")
        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            "[BIQ][BCM] GattCallback: Notification received on: ${characteristic.uuid}".logDebugMessage()
            notifyMap.remove(characteristic.uuid)?.complete(characteristic.value)
                ?: "[BIQ][BCM] GattCallback: No listener for UUID: ${characteristic.uuid}".logWarningMessage()
        }

        fun prepareMtu() = mtuDeferred
        suspend fun awaitMtu() = mtuDeferred.await()
        fun prepareServices() = svcDeferred
        suspend fun awaitServices() = svcDeferred.await()
        suspend fun awaitConnection() = connectDeferred.await()

        fun prepareRead(uuid: UUID): CompletableDeferred<ByteArray> {
            val deferred = CompletableDeferred<ByteArray>()
            readMap[uuid] = deferred
            return deferred
        }

        fun prepareWrite(u: UUID): CompletableDeferred<Unit> {
            val deferred = CompletableDeferred<Unit>()
            writeMap[u] = deferred
            return deferred
        }

        fun prepareDescriptor(desc: BluetoothGattDescriptor): CompletableDeferred<Unit> {
            val deferred = CompletableDeferred<Unit>()
            descriptorMap[desc] = deferred
            return deferred
        }

        fun prepareNotify(char: BluetoothGattCharacteristic): CompletableDeferred<ByteArray> {
            val deferred = CompletableDeferred<ByteArray>()
            notifyMap[char.uuid] = deferred
            return deferred
        }
    }

    private suspend fun getNonce(): String = nonceCacheMutex.withLock {
        val now = LocalDateTime.now()
        val cached = cachedNonce
        
        // Check if cached nonce exists and is still valid
        if (cached != null && cached.timestamp.isAfter(now.minusSeconds(NONCE_VALIDITY_SECONDS))) {
            "[BIQ][BCM] Using cached nonce (age: ${Duration.between(cached.timestamp, now).seconds}s)".logDebugMessage()
            return cached.nonce
        }
        
        // Fetch new nonce
        "[BIQ][BCM] Fetching new nonce".logDebugMessage()
        val newNonce = PresenceProofServiceRepository.getNonce()
        cachedNonce = CachedNonce(newNonce, now)
        return newNonce
    }

    private suspend fun sendSignature(signature: PeripheralSignature, macAddress: String): PresenceProofResponseDto =
        enqueueValidation(signature, macAddress)

    private suspend fun enqueueValidation(signature: PeripheralSignature, macAddress: String): PresenceProofResponseDto {
        val request = signature.toRequestDto()
        val deferred = CompletableDeferred<PresenceProofResponseDto>()
        val pendingValidation = PendingValidation(request, macAddress, deferred)

        validationQueueMutex.withLock {
            if (validationWindowClosed) {
                "[BIQ][BCM] Ignoring validation request because batching window has closed".logWarningMessage()
                throw ValidationWindowClosedException()
            }
            validationQueue.add(pendingValidation)
            if (validationDispatchJob?.isActive != true) {
                validationDispatchJob = validationScope.launch { dispatchValidationQueue() }
            }
        }

        deferred.invokeOnCompletion { cause ->
            if (cause is CancellationException) {
                validationScope.launch {
                    validationQueueMutex.withLock {
                        validationQueue.remove(pendingValidation)
                    }
                }
            }
        }

        return deferred.await()
    }

    private suspend fun dispatchValidationQueue() {
        delay(VALIDATION_BATCH_DELAY_MS)

        val batch = validationQueueMutex.withLock {
            if (validationQueue.isEmpty()) {
                validationWindowClosed = false
                validationDispatchJob = null
                emptyList()
            } else {
                validationWindowClosed = true
                val queued = validationQueue.toList()
                validationQueue.clear()
                validationDispatchJob = null
                queued
            }
        }

        if (batch.isEmpty()) {
            "[BIQ][BCM] No validations to dispatch; batching window remains open".logInfoMessage()
            return
        }

        "[BIQ][BCM] Dispatching ${batch.size} validation(s) after batching delay".logDebugMessage()

        try {
            val response = PresenceProofServiceRepository.validateSignatures(
                batch.map { it.request }
            )
            clearCachedNonce()

            val batchSummary = batch.joinToString { pending ->
                val req = pending.request
                "${req.uuid}:${req.major}:${req.minor} (device=${pending.macAddress})"
            }
            "[BIQ][BCM] BLE validation batch success (count=${batch.size}): $batchSummary".logInfoMessage()

            DatabaseProvider.getEventRepository().insertAll(response.events)
            BiqController.getInstance().notifyValidationRecordsChange(response.events)
            DebugPrefsManager.saveValidationTimestamp(response.events.joinToString { it.id })

            // Complete all pending validations
            batch.forEach { pending ->
                if (!pending.deferred.isCompleted) {
                    pending.deferred.complete(response)
                }
            }
        } catch (e: Exception) {
            clearCachedNonce()
            "[BIQ][BCM] Validation batch failed: ${e.message}".logErrorMessage()
            validationQueueMutex.withLock { validationWindowClosed = false }
            batch.forEach { pending ->
                if (!pending.deferred.isCompleted) {
                    pending.deferred.completeExceptionally(e)
                }
            }
        }
    }

    private fun PeripheralSignature.toRequestDto() = PresenceProofRequestDto(
        uuid = uuid,
        major = major,
        minor = minor,
        publicKey = publicKey,
        signature = signature
    )

    private fun updateScanningInProgressIfNotPaused() {
        if (ConnectionStateProvider.scanningState == BiqScanningState.SCANNING_PAUSED) {
            "[BIQ][BCM] Skipping scan state update because scanning is paused".logDebugMessage()
            return
        }
        ConnectionStateProvider.updateState(BiqPresenceState.SCANNING_IN_PROGRESS)
    }

    suspend fun stopValidation() {
        validationQueueMutex.withLock {
            validationDispatchJob?.cancel()
            validationDispatchJob = null
            validationWindowClosed = false

            validationQueue.forEach { pending ->
                if (!pending.deferred.isCompleted) {
                    pending.deferred.cancel(CancellationException("Validation cancelled"))
                }
            }
            validationQueue.clear()
            clearCachedNonce()
            devicesBeingValidated.clear()
            devicesUsedForValidation.clear()

            validationScopeJob.cancel()
            validationScopeJob = SupervisorJob()
            validationScope = CoroutineScope(validationScopeJob + Dispatchers.IO)
        }
    }

    private suspend fun clearCachedNonce() = nonceCacheMutex.withLock {
        cachedNonce = null
    }

    private class ValidationWindowClosedException : Exception("Validation window closed")

    suspend fun openValidationWindow() = validationQueueMutex.withLock {
        validationWindowClosed = false
        devicesUsedForValidation.clear()
    }
}

suspend fun <T> retryBLE(
    times: Int = 3,
    delayMillis: Long = 750,
    block: suspend () -> T
): T {
    var lastError: Throwable? = null
    repeat(times) {
        try {
            return block()
        } catch (e: Throwable) {
            lastError = e
            delay(delayMillis)
        }
    }
    throw lastError ?: IllegalStateException("BLE operation failed")
}
