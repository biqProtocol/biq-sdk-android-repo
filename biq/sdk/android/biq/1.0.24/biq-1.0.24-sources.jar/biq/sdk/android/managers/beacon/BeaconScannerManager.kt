package biq.sdk.android.managers.beacon

import android.annotation.SuppressLint
import androidx.lifecycle.Observer
import biq.sdk.android.BiqController
import biq.sdk.android.BuildConfig
import biq.sdk.android.helpers.ConnectionState
import biq.sdk.android.helpers.extensions.logDebugMessage
import biq.sdk.android.managers.NetworkConnectivityManager
import biq.sdk.android.managers.NotificationsManager
import biq.sdk.android.managers.PermissionsManager
import biq.sdk.android.managers.bluetooth.BluetoothCommunicationManager
import biq.sdk.android.managers.bluetooth.BluetoothScannerManager
import biq.sdk.android.managers.preferences.DebugPrefsManager
import biq.sdk.android.models.BiqPresenceState
import biq.sdk.android.providers.ConnectionStateProvider
import biq.sdk.android.providers.ContextProvider
import biq.sdk.android.providers.CoroutineScopeProvider
import biq.sdk.android.providers.DatabaseProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.altbeacon.beacon.Beacon
import org.altbeacon.beacon.BeaconManager
import org.altbeacon.beacon.MonitorNotifier
import org.altbeacon.beacon.Settings
import java.time.LocalDateTime
import java.util.UUID

internal class BeaconScannerManager() {

    companion object {
        const val TAG = "BeaconScannerManager"

        /***
         * Maximum time allowed, in milliseconds, inside a beacon region.
         */
        const val RANGE_INSIDE_MILLIS = 10_000L

        /***
         * Rerun ranging every N minutes inside a beacon region.
         */
        const val RANGING_LOOP_MINUTES = 5L

        /***
         * Prevent a validation to happen more than N minutes after the last one.
         */
        const val VALIDATION_RESTRICTION_MINUTES = 4L

        /***
         * Delay after stopping scanning to let the BLE stack settle after heavy GATT operations.
         * This helps prevent the BLE stack from being in a degraded state when ranging restarts.
         */
        const val BLE_STACK_SETTLE_DELAY_MS = 2_000L

        /***
         * Number of consecutive zero-beacon ranging callbacks before triggering a forced restart.
         * This helps recover from BLE stack degradation.
         */
        const val ZERO_RANGING_THRESHOLD = 5
        
        /**
         * Maximum number of force restarts allowed per scanning session.
         * Prevents infinite restart loops when beacons are truly out of range.
         */
        const val MAX_FORCE_RESTARTS = 2

        /**
         * Delay before confirming OUTSIDE status to avoid false positives.
         * The AltBeacon monitor can sometimes incorrectly report OUTSIDE.
         */
        const val OUTSIDE_CONFIRMATION_DELAY_MS = 5_000L
    }

    private val beaconUtils = BeaconUtils()

    private var beaconManager: BeaconManager? = null
    private var isScanning = false

    private var rangingLoopJob: Job? = null
    private var outsideConfirmationJob: Job? = null

    @Volatile
    private var consecutiveZeroRangings = 0
    
    @Volatile
    private var beaconRangedThisSession = false
    
    @Volatile
    private var forceRestartCount = 0

    data class BeaconKey(
        val uuid: UUID,
        val major: Int,
        val minor: Int
    )

    @SuppressLint("MissingPermission")
    private val centralMonitoringObserver = Observer<Int> { state ->
        "[BIQ][BSM] centralMonitoringObserver state: $state".logDebugMessage()

        if (state == MonitorNotifier.OUTSIDE) {
            // Cancel any pending confirmation and schedule a new one
            // This prevents false OUTSIDE detections from stopping scanning prematurely
            outsideConfirmationJob?.cancel()
            outsideConfirmationJob = CoroutineScopeProvider.get().launch {
                "[BIQ][BSM] OUTSIDE detected, waiting ${OUTSIDE_CONFIRMATION_DELAY_MS}ms to confirm...".logDebugMessage(TAG)
                delay(OUTSIDE_CONFIRMATION_DELAY_MS)
                
                // After delay, confirm we're still outside (no INSIDE event cancelled us)
                withContext(Dispatchers.Main) {
                    "[BIQ][BSM] OUTSIDE confirmed after delay.".logDebugMessage(TAG)
                    beaconUtils.onMonitorNotifier(state)
                    rangingLoopJob?.cancel()

                    "[BIQ][BSM] Outside beacon region.".logDebugMessage(TAG)
                    beaconUtils.stopRangingBeacons()
                    BluetoothScannerManager.stopScan()
                    consecutiveZeroRangings = 0

                    ConnectionStateProvider.updateState(BiqPresenceState.SCANNING_IN_PROGRESS)
                }
            }
        } else {
            // INSIDE detected - cancel any pending OUTSIDE confirmation
            outsideConfirmationJob?.cancel()
            outsideConfirmationJob = null
            
            beaconUtils.onMonitorNotifier(state)

            "[BIQ][BSM] Inside beacon region.".logDebugMessage(TAG)
            startRangingLoop()

            ConnectionStateProvider.updateState(BiqPresenceState.INSIDE_BEACON_RANGE)

            NotificationsManager.sendNearbyNotification()
        }
    }

    @SuppressLint("MissingPermission")
    private val centralRangingObserver = Observer<Collection<Beacon>> { beacons ->
        "[BIQ][BSM] Ranged: ${beacons.count()} beacons".logDebugMessage(TAG)

        if (beacons.isEmpty() && beaconUtils.isInsideRegion) {
            consecutiveZeroRangings++
            // Only force restart if:
            // 1. We haven't found any beacon this session (BLE stack might be stuck)
            // 2. We haven't exceeded the max restart limit
            if (consecutiveZeroRangings >= ZERO_RANGING_THRESHOLD && !beaconRangedThisSession) {
                if (forceRestartCount < MAX_FORCE_RESTARTS) {
                    forceRestartCount++
                    "[BIQ][BSM] Detected $consecutiveZeroRangings consecutive zero-beacon rangings (no beacons this session). Forcing restart ($forceRestartCount/$MAX_FORCE_RESTARTS).".logDebugMessage(TAG)
                    consecutiveZeroRangings = 0
                    beaconUtils.forceRestartRanging()
                    return@Observer
                } else {
                    "[BIQ][BSM] Max force restarts reached ($MAX_FORCE_RESTARTS). Waiting for monitor to detect OUTSIDE.".logDebugMessage(TAG)
                }
            }
        } else {
            consecutiveZeroRangings = 0
        }

        for (beacon: Beacon in beacons) {
            beaconRangedThisSession = true
            "[BIQ][BSM] Found beacon: $beacon about ${beacon.distance} meters away".logDebugMessage(
                TAG
            )
            val beaconId = beacon.id1.toUuid()
            if (BluetoothCommunicationManager.BEACON_UUID == beaconId) {
                BluetoothScannerManager.startScan()
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startRangingLoop() {
        rangingLoopJob?.cancel()

        rangingLoopJob = CoroutineScopeProvider.get().launch {
            do {
                // Early exit check - ensure we're still inside region before starting iteration
                ensureActive()
                if (!beaconUtils.isInsideRegion) {
                    "[BIQ][BSM] Ranging loop cancelled - no longer inside beacon region.".logDebugMessage(TAG)
                    break
                }

                // Reset session flags at the start of each ranging window
                beaconRangedThisSession = false
                forceRestartCount = 0

                withContext(Dispatchers.Main) {
                    "[BIQ][BSM] Attemp ranging for beacons.".apply {
                        logDebugMessage(TAG)
                        DebugPrefsManager.saveValidationLog(this)
                    }

                    BluetoothCommunicationManager.openValidationWindow()
                    beaconUtils.startRangingBeacons()
                }

                delay(RANGE_INSIDE_MILLIS)

                withContext(Dispatchers.Main) {
                    "[BIQ][BSM] Stopping ranging after ${RANGE_INSIDE_MILLIS / 1000L} seconds or because of a network error".apply {
                        logDebugMessage(TAG)
                        DebugPrefsManager.saveValidationLog(this)
                    }

                    softPauseScanning()
                    consecutiveZeroRangings = 0
                }

                // Check again before long delay
                if (!beaconUtils.isInsideRegion || !isActive) {
                    "[BIQ][BSM] Ranging loop exiting before delay - outside region or cancelled.".logDebugMessage(TAG)
                    break
                }

                delay(BLE_STACK_SETTLE_DELAY_MS)

                when (BuildConfig.DEBUG) {
                    true -> when (NetworkConnectivityManager.isConnected()) {
                        true -> delay(5L * 60 * 1000L - BLE_STACK_SETTLE_DELAY_MS)
                        false -> delay(1L * 60 * 1000L - BLE_STACK_SETTLE_DELAY_MS)
                    }

                    else -> when (NetworkConnectivityManager.isConnected()) {
                        true -> delay(RANGING_LOOP_MINUTES * 60 * 1000L - BLE_STACK_SETTLE_DELAY_MS)
                        false -> delay(2L * 60 * 1000L - BLE_STACK_SETTLE_DELAY_MS)
                    }
                }

            } while (beaconUtils.isInsideRegion && isActive)
        }
    }

    @SuppressLint("MissingPermission")
    private fun softPauseScanning() {
        beaconUtils.stopRangingBeacons()
        BluetoothScannerManager.stopScan()
    }

    fun pauseScanning() {
        rangingLoopJob?.cancel()
        rangingLoopJob = null
        outsideConfirmationJob?.cancel()
        outsideConfirmationJob = null
        softPauseScanning()
        consecutiveZeroRangings = 0
        beaconRangedThisSession = false
        forceRestartCount = 0
    }

    fun resumeScanning(isForced: Boolean): Boolean {
        if (!isScanning) return false

        BluetoothScannerManager.resetValidatedDevices()

        if (beaconUtils.isInsideRegion || isForced) {
            startRangingLoop()
            return true
        }

        return false
    }

    @SuppressLint("MissingPermission")
    fun startScanning(): ConnectionState {
        if (!NetworkConnectivityManager.isConnected()) {
            return ConnectionState.Error(
                state = BiqPresenceState.NETWORK_ERROR
            )
        }

        if (!BiqController.getInstance().isBluetoothEnabled()) {
            return ConnectionState.Error(
                state = BiqPresenceState.BLUETOOTH_ERROR
            )
        }

        if (!BiqController.getInstance().isLocationEnabled()) {
            return ConnectionState.Error(
                state = BiqPresenceState.LOCATION_ERROR
            )
        }

        if (isScanning) {
            return ConnectionState.Error(
                state = BiqPresenceState.SCANNING_IN_PROGRESS
            )
        }

        PermissionsManager.getMissingPermission()?.let {
            ConnectionStateProvider.updateState(BiqPresenceState.PERMISSION_ERROR)
            return ConnectionState.MissingPermission(it)
        }

        // Reset all state for a fresh start
        BluetoothScannerManager.resetValidatedDevices()
        consecutiveZeroRangings = 0
        beaconRangedThisSession = false
        forceRestartCount = 0
        
        isScanning = true
        setupBeaconScanning()

        ConnectionStateProvider.updateState(BiqPresenceState.SCANNING_IN_PROGRESS)
        return ConnectionState.Success(
            state = BiqPresenceState.SCANNING_IN_PROGRESS
        )
    }

    @SuppressLint("MissingPermission")
    fun stopScanning() {
        outsideConfirmationJob?.cancel()
        outsideConfirmationJob = null
        
        CoroutineScopeProvider.get().launch {
            BluetoothScannerManager.stopScan()

            BluetoothCommunicationManager.stopValidation()

            beaconUtils.stopMonitoringBeacon()
            beaconUtils.stopRangingBeacons()

            DatabaseProvider.getEventRepository().deleteAll()
            BiqController.getInstance().notifyValidationRecordsChange(listOf())

            withContext(Dispatchers.Main) {
                BeaconManager.getInstanceForApplication(ContextProvider.get())
                    .getRegionViewModel(beaconUtils.iBeaconRegion).apply {
                        this.regionState.removeObserver(centralMonitoringObserver)
                        this.rangedBeacons.removeObserver(centralRangingObserver)
                    }
            }

            beaconManager?.apply {
                this.removeAllMonitorNotifiers()
                this.removeAllRangeNotifiers()
            }

            NotificationsManager.cancelScanningNotification()

            isScanning = false

            ConnectionStateProvider.updateState(BiqPresenceState.SCANNING_NOT_STARTED)

            CoroutineScopeProvider.destroy()
        }
    }

    private fun setupBeaconScanning() {
        val beaconManager = BeaconManager.getInstanceForApplication(ContextProvider.get())

        val settings = getForegroundServiceScanningSettings()
        beaconManager.replaceSettings(settings)
//        beaconManager.adjustSettings(Settings(debug = true))

        beaconUtils.startMonitoringBeacon()

        CoroutineScopeProvider.get().launch {
            withContext(Dispatchers.Main) {
                val regionViewModel =
                    BeaconManager.getInstanceForApplication(ContextProvider.get())
                        .getRegionViewModel(beaconUtils.iBeaconRegion)
                // observer will be called each time the monitored regionState changes (inside vs. outside region)
                regionViewModel.regionState.observeForever(centralMonitoringObserver)
                // observer will be called each time a new list of beacons is ranged (typically ~1 second in the foreground)
                regionViewModel.rangedBeacons.observeForever(centralRangingObserver)
            }
        }

        this.beaconManager = beaconManager
    }

    private fun getForegroundServiceScanningSettings() = Settings(
        scanStrategy = Settings.ForegroundServiceScanStrategy(
            NotificationsManager.getScanningForegroundNotification(),
            NotificationsManager.BIQ_SCANNING_NOTIFICATION_ID
        ),
        scanPeriods = Settings.ScanPeriods(
            1100,
            0,
            1100,
            0
        ),
        longScanForcingEnabled = true
    )
}
